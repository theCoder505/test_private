<?php

namespace App\Http\Controllers\surface;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AllPagesController extends Controller
{





    public function showHomePage(){
        $data1 = '';
        return view('surface.pages.home', compact('data1'));
    }





    public function readBlogsPage(){
        $data1 = '';
        return view('surface.pages.blogs', compact('data1'));
    }





    public function esictingBrnadsPage(){
        $data1 = '';
        return view('surface.pages.existing-brands', compact('data1'));
    }





    public function newBrandsPage(){
        $data1 = '';
        return view('surface.pages.new-brands', compact('data1'));
    }












    //
}
