

<?php $__env->startSection('title'); ?>
    Edit/Update Custom Project <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .portal_line {
            padding: 50px;
            border-radius: 15px;
            border: 2px solid #000 !important;
            background: #fff;
        }
    </style>


    <!-- // main webpage content is here  -->
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <div class="col-12 allAlerts">
                            <?php if(session()->has('alertMsg')): ?>
                                <div class="alert text-center <?php echo e(session()->get('type')); ?> alert-dismissible fade show"
                                    role="alert">
                                    <?php echo e(session()->get('alertMsg')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>

                        <h2 class="centered_text"> View/Update Particular Project </h2>

                        <div class="portal_line">

                            <?php $__empty_1 = true; $__currentLoopData = $vendor_product_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div id="complete_profile">
                                    <form action="/influencer/edit-existing-custom-requested-product" method="post"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group">
                                            <label> Projects Photos </label>
                                            <input type="file" class="form-control" name="project_photos[]"
                                                accept="image/*" multiple onchange="showMultipleImages(this)">
                                        </div>

                                        <div id="multple_gallery">
                                            <?php
                                                if ($item->project_photos != '') {
                                                    $images = explode('|', $item->project_photos);
                                                    foreach ($images as $key => $imgsrc) {
                                                        echo '<div class="gallery_line"><img src="' . $imgsrc . '"/></div>';
                                                    }
                                                }
                                            ?>
                                        </div>

                                        <input type="hidden" name="product_id" value="<?php echo e($item->sno); ?>">


                                        <div class="form-group">
                                            <label>Item Name</label>
                                            <input type="text" class="form-control" required
                                                value="<?php echo e($item->item_name); ?>" name="item_name">
                                        </div>

                                        <div class="form-group">
                                            <label>Describe The Product</label>
                                            <textarea class="form-control" id="comp_bio" name="prod_desc" rows="3" required><?php echo e($item->prod_desc); ?></textarea>
                                        </div>


                                        <div class="row mt-3">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label> Sample Price (In $) </label>
                                                    <input type="number" class="form-control" required
                                                        value="<?php echo e($item->sample_price); ?>" name="sample_price">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label> Sample MOQ <small class="text-warning">Input the number of units
                                                            the
                                                            sample contains. This is usually "1".</small> </label>
                                                    <input type="number" class="form-control" required
                                                        value="<?php echo e($item->sample_moq); ?>" name="sample_moq">
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label> What will the Influencer receive? </label>
                                                    <input type="text" class="form-control" required
                                                        value="<?php echo e($item->what_receives); ?>" name="what_receives">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label> Production Per Unit Cost (In $) </label>
                                                    <input type="number" class="form-control" required
                                                        value="<?php echo e($item->prod_unit_cost); ?>" name="prod_unit_cost">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label> Production MOQ</label>
                                                    <input type="number" class="form-control" required
                                                        value="<?php echo e($item->prod_mcq); ?>" name="prod_mcq">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="">Category</label>
                                            <select name="product_category" id="" class="form-control">
                                                <option <?php if($item->product_category == 'Category Option 1'): ?> selected <?php endif; ?>
                                                    value="Category Option 1">Category Option 1</option>
                                                <option <?php if($item->product_category == 'Category Option 2'): ?> selected <?php endif; ?>
                                                    value="Category Option 2">Category Option 2</option>
                                                <option <?php if($item->product_category == 'Category Option 3'): ?> selected <?php endif; ?>
                                                    value="Category Option 3">Category Option 3</option>
                                                <option <?php if($item->product_category == 'Category Option 4'): ?> selected <?php endif; ?>
                                                    value="Category Option 4">Category Option 4</option>
                                                <option <?php if($item->product_category == 'Category Option 5'): ?> selected <?php endif; ?>
                                                    value="Category Option 5">Category Option 5</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label> Sku Number <small class="text-warning">This is used for your personal
                                                    item
                                                    management and is not visible to your customer.</small> </label>
                                            <input type="number" class="form-control" required
                                                value="<?php echo e($item->skunumber); ?>" name="skunumber">
                                        </div>


                                        <center>
                                            <button class="btn btn-dark px-5">Update Product</button>
                                        </center>

                                    </form>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".products").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('influencers.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/influencers/pages/edit_custom_product.blade.php ENDPATH**/ ?>