

<?php $__env->startSection('title'); ?>
    Read Our Posts | <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="all_post_tablines">
        <div class="post_tabline active_line" data-id="all" onclick="showPosts(this)"> All Posts </div>
        <div class="post_tabline" data-id="economy" onclick="showPosts(this)"> Creator Economy </div>
        <div class="post_tabline" data-id="four" onclick="showPosts(this)"> The Four C's </div>
        <div class="post_tabline" data-id="funny" onclick="showPosts(this)"> It's A Funny Story </div>
        <div class="post_tabline" data-id="announcement" onclick="showPosts(this)"> Announcements </div>
    </div>


    <div class="blog-container">


        <div class="blog_item four">
            <img src="/surface/assets/blogimages/blog1.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>



        <div class="blog_item four">
            <img src="/surface/assets/blogimages/blog1.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>

        <div class="blog_item four">
            <img src="/surface/assets/blogimages/blog2.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>

        <div class="blog_item four">
            <img src="/surface/assets/blogimages/blog3.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>

        <div class="blog_item four">
            <img src="/surface/assets/blogimages/blog4.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>





        <div class="blog_item funny">
            <img src="/surface/assets/blogimages/blog5.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>







        <div class="blog_item funny">
            <img src="/surface/assets/blogimages/blog1.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>

        <div class="blog_item funny">
            <img src="/surface/assets/blogimages/blog2.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>

        <div class="blog_item funny">
            <img src="/surface/assets/blogimages/blog3.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>

        <div class="blog_item economy">
            <img src="/surface/assets/blogimages/blog4.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>






        <div class="blog_item economy">
            <img src="/surface/assets/blogimages/blog6.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>







        <div class="blog_item announcement">
            <img src="/surface/assets/blogimages/blog1.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>

        <div class="blog_item announcement">
            <img src="/surface/assets/blogimages/blog2.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>

        <div class="blog_item announcement">
            <img src="/surface/assets/blogimages/blog3.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>

        <div class="blog_item announcement">
            <img src="/surface/assets/blogimages/blog4.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>






        <div class="blog_item announcement">
            <img src="/surface/assets/blogimages/blog6.jpg" alt="" class="blog_img">
            <div class="blog_detail_part">
                <h2 class="blog_title">
                    How to Start Your Own Makeup Line
                </h2>
                <div class="blog_time">
                    August 11, 2022
                </div>
                <p class="blog_small_desc">
                    One of the most challenging aspects of running an online store is managing the shipping and handling
                    of
                    customer's orders. When handling customer service, creating marketing campaigns, and running a
                    website,
                    it can be hard to add more responsibilities on top, especially tracking down products and shipping
                    them
                    to the right address.
                </p>
                <a class="read_more_blog">
                    Read More
                </a>
            </div>
        </div>



    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        $(".blogs").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/surface/pages/blogs.blade.php ENDPATH**/ ?>