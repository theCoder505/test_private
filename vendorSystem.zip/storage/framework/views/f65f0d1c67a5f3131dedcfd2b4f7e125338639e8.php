<footer class="footer_section">

</footer><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/surface/layouts/footer.blade.php ENDPATH**/ ?>