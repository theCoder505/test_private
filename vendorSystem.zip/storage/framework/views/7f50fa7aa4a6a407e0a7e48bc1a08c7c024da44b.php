

<?php $__env->startSection('title'); ?>
    New Brands - <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <section class="first_section">
        <h1 class="next_gen_capital_text"> The Fastest, Easiest, And Most Affordable <br> Way To Start Your Brand.</h1>

        <p class="getup_text">Get up and running in no time.</p>

        <center>
            <button class="startFreeBtn" onclick="showSignUp()">Create Free Account</button>
        </center>


        <div class="container my-5">

            <div class="row affordable">


                <div class="col-md-4">
                    <div class="image_holder">
                        <img src="/surface/assets/images/brand1.png" alt="" class="afford_img">
                    </div>
                    <p class="affordable_heading">Find Your Suppliers</p>
                    <p class="affordable_para">Work with 1000+ suppliers across 30 different product categories who are
                        waiting to work with you.</p>
                </div>

                <div class="col-md-4">
                    <div class="image_holder">
                        <img src="/surface/assets/images/brand2.png" alt="" class="afford_img">
                    </div>
                    <p class="affordable_heading">Set Up Order Fulfillment</p>
                    <p class="affordable_para">Work with 1000+ suppliers across 30 different product categories who are
                        waiting to work with you.</p>
                </div>

                <div class="col-md-4">
                    <div class="image_holder">
                        <img src="/surface/assets/images/brand3.png" alt="" class="afford_img">
                    </div>
                    <p class="affordable_heading">Set Up Your eCommerce</p>
                    <p class="affordable_para">Work with 1000+ suppliers across 30 different product categories who are
                        waiting to work with you.</p>
                </div>


            </div>

        </div>


        <div class="container">
            <div class="grid_petra_4_lines d-none">

                <div class="petra_line">
                    <div class="text-center">
                        <img src="/surface/assets/images/petra1.png" alt="" class="petra_img">
                    </div>
                    <p class="petra_heading">Launch New Product Lines</p>
                    <p class="petra_details">
                        Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                        design products and packaging.
                    </p>
                </div>

                <div class="petra_line">
                    <div class="text-center">
                        <img src="/surface/assets/images/petra2.png" alt="" class="petra_img">
                    </div>
                    <p class="petra_heading">Streamline Your Fulfillment</p>
                    <p class="petra_details">
                        Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                        design products and packaging.
                    </p>
                </div>

                <div class="petra_line">
                    <div class="text-center">
                        <img src="/surface/assets/images/petra3.png" alt="" class="petra_img">
                    </div>
                    <p class="petra_heading">Scale & Manage Your Operations</p>
                    <p class="petra_details">
                        Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                        design products and packaging.
                    </p>
                </div>

                <div class="petra_line">
                    <div class="text-center">
                        <img src="/surface/assets/images/petra2.png" alt="" class="petra_img">
                    </div>
                    <p class="petra_heading">Streamline Your Fulfillment 4</p>
                    <p class="petra_details">
                        Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                        design products and packaging.
                    </p>
                </div>

                <div class="petra_line">
                    <div class="text-center">
                        <img src="/surface/assets/images/petra1.png" alt="" class="petra_img">
                    </div>
                    <p class="petra_heading">Launch New Product Lines</p>
                    <p class="petra_details">
                        Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                        design products and packaging.
                    </p>
                </div>

                <div class="petra_line">
                    <div class="text-center">
                        <img src="/surface/assets/images/petra2.png" alt="" class="petra_img">
                    </div>
                    <p class="petra_heading">Streamline Your Fulfillment</p>
                    <p class="petra_details">
                        Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                        design products and packaging.
                    </p>
                </div>

                <div class="petra_line">
                    <div class="text-center">
                        <img src="/surface/assets/images/petra3.png" alt="" class="petra_img">
                    </div>
                    <p class="petra_heading">Scale & Manage Your Operations</p>
                    <p class="petra_details">
                        Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                        design products and packaging.
                    </p>
                </div>

                <div class="petra_line">
                    <div class="text-center">
                        <img src="/surface/assets/images/petra2.png" alt="" class="petra_img">
                    </div>
                    <p class="petra_heading">Streamline Your Fulfillment 4</p>
                    <p class="petra_details">
                        Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                        design products and packaging.
                    </p>
                </div>

            </div>
        </div>


        <div class="text-center">
            <button class="see_more_less">See More</button>
        </div>


    </section>




    <section class="petra_ways">
        <h1 class="ways_petra_text"> Ways To Use Pietra </h1>

        <div class="grid_petra">

            <div class="petra_line">
                <div class="text-center">
                    <img src="/surface/assets/images/petra1.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Launch New Product Lines</p>
                <p class="petra_details">
                    Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                    design products and packaging.
                </p>
                <p class="petra_red">
                    "It's like Alibaba, but better, safer, and easier to use."
                </p>
            </div>

            <div class="petra_line">
                <div class="text-center">
                    <img src="/surface/assets/images/petra2.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Streamline Your Fulfillment</p>
                <p class="petra_details">
                    Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                    design products and packaging.
                </p>
                <p class="petra_red">
                    "It's like Alibaba, but better, safer, and easier to use."
                </p>
            </div>

            <div class="petra_line">
                <div class="text-center">
                    <img src="/surface/assets/images/petra3.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Scale & Manage Your Operations</p>
                <p class="petra_details">
                    Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                    design products and packaging.
                </p>
                <p class="petra_red">
                    "It's like Alibaba, but better, safer, and easier to use."
                </p>
            </div>



        </div>
    </section>




    <section class="smartest_operator">
        <h1 class="next_gen_capital_text"> For The Smartest eCommerce Operators </h1>
        <div class="container">

            <div class="row ecomLine">
                <div class="center_items col-md-6">
                    <div class="text_holder">
                        <h1 class="ecom_header">
                            Looking for suppliers? From merch to custom manufacturers,it's all here.
                        </h1>
                        <p class="ecom_para">
                            Access hand-picked, high-quality suppliers specializing in 50+ product categories. If you
                            can
                            dream it, you can source it on Pietra.
                        </p>
                        <p class="ecom_para last_para">
                            <b>Pro Tip:</b> Pietra is the most affordable way to pay your suppliers. Save 5-10% in fees
                            when
                            you invite and pay your existing suppliers.
                        </p>

                        <a href="/" class="btn learnmorebtn">Learn More → </a>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="/surface/assets/images/ecom1.png" alt="" class="ecomImage">
                </div>
            </div>

            <div class="row ecomLine">
                <div class="col-md-6">
                    <img src="/surface/assets/images/ecom2.png" alt="" class="ecomImage">
                </div>
                <div class="center_items col-md-6">
                    <div class="text_holder">
                        <h1 class="ecom_header">
                            Looking for suppliers? From merch to custom manufacturers,it's all here.
                        </h1>
                        <p class="ecom_para">
                            Access hand-picked, high-quality suppliers specializing in 50+ product categories. If you
                            can
                            dream it, you can source it on Pietra.
                        </p>
                        <p class="ecom_para last_para">
                            <b>Pro Tip:</b> Pietra is the most affordable way to pay your suppliers. Save 5-10% in fees
                            when
                            you invite and pay your existing suppliers.
                        </p>

                        <a href="/" class="btn learnmorebtn">Learn More → </a>
                    </div>
                </div>
            </div>

            <div class="row ecomLine">
                <div class="center_items col-md-6">
                    <div class="text_holder">
                        <h1 class="ecom_header">
                            Looking for suppliers? From merch to custom manufacturers,it's all here.
                        </h1>
                        <p class="ecom_para">
                            Access hand-picked, high-quality suppliers specializing in 50+ product categories. If you
                            can
                            dream it, you can source it on Pietra.
                        </p>
                        <p class="ecom_para last_para">
                            <b>Pro Tip:</b> Pietra is the most affordable way to pay your suppliers. Save 5-10% in fees
                            when
                            you invite and pay your existing suppliers.
                        </p>

                        <a href="/" class="btn learnmorebtn">Learn More → </a>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="/surface/assets/images/ecom3.png" alt="" class="ecomImage">
                </div>
            </div>

            <div class="row ecomLine">
                <div class="col-md-6">
                    <img src="/surface/assets/images/ecom4.png" alt="" class="ecomImage">
                </div>
                <div class="center_items col-md-6">
                    <div class="text_holder">
                        <h1 class="ecom_header">
                            Looking for suppliers? From merch to custom manufacturers,it's all here.
                        </h1>
                        <p class="ecom_para">
                            Access hand-picked, high-quality suppliers specializing in 50+ product categories. If you
                            can
                            dream it, you can source it on Pietra.
                        </p>
                        <p class="ecom_para last_para">
                            <b>Pro Tip:</b> Pietra is the most affordable way to pay your suppliers. Save 5-10% in fees
                            when
                            you invite and pay your existing suppliers.
                        </p>

                        <a href="/" class="btn learnmorebtn">Learn More → </a>
                    </div>
                </div>
            </div>

        </div>
    </section>



    <section class="all_reviews">
        <h1 class="ways_petra_text"> The Reviews Are In </h1>

        <div class="container">

            <div id="all_review_lines" class="owl-carousel owl-theme">

                <div class="item review_line">
                    <div class="left_part">
                        <p class="left_header">FORM by Sami Clarke</p>
                        <p class="left_details">
                            We have absolutely loved working with Pietra! Their suppliers are top tier, customer service
                            is
                            exceptional and they make operating a storefront extremely simple.
                        </p>
                    </div>
                    <div class="right_part">
                        <img src="/surface/assets/images/review1.jpg" alt="" class="right_part_img">
                    </div>
                </div>

                <div class="item review_line">
                    <div class="left_part">
                        <p class="left_header">FORM by Sami Clarke 2</p>
                        <p class="left_details">
                            We have absolutely loved working with Pietra! Their suppliers are top tier, customer service
                            is
                            exceptional and they make operating a storefront extremely simple.
                        </p>
                    </div>
                    <div class="right_part">
                        <img src="/surface/assets/images/review1.jpg" alt="" class="right_part_img">
                    </div>
                </div>

                <div class="item review_line">
                    <div class="left_part">
                        <p class="left_header">FORM by Sami Clarke 3</p>
                        <p class="left_details">
                            We have absolutely loved working with Pietra! Their suppliers are top tier, customer service
                            is
                            exceptional and they make operating a storefront extremely simple.
                        </p>
                    </div>
                    <div class="right_part">
                        <img src="/surface/assets/images/review1.jpg" alt="" class="right_part_img">
                    </div>
                </div>

                <div class="item review_line">
                    <div class="left_part">
                        <p class="left_header">FORM by Sami Clarke 4</p>
                        <p class="left_details">
                            We have absolutely loved working with Pietra! Their suppliers are top tier, customer service
                            is
                            exceptional and they make operating a storefront extremely simple.
                        </p>
                    </div>
                    <div class="right_part">
                        <img src="/surface/assets/images/review1.jpg" alt="" class="right_part_img">
                    </div>
                </div>

            </div>

        </div>


        <center>
            <button class="startFreeBtn mt-5" onclick="showSignUp()">Start For Free</button>
        </center>

    </section>




    <section class="petra_ways">
        <h1 class="ways_petra_text"> One Subscription Gives You Access To </h1>

        <div class="grid_petra_4">

            <div class="petra_line">
                <div class="petra_img_line">
                    <img src="/surface/assets/images/plan.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Get your own personalized business plan.</p>
                <p class="petra_details">
                    Pietra gives you a personalized business plan that you can work through, step-by-step, to launch
                    your business. <br>
                    Get access to workshops, get supplier recommendations, and even finance your first production run.
                </p>
            </div>

            <div class="petra_line">
                <div class="petra_img_line">
                    <img src="/surface/assets/images/plan.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Find new suppliers and manage existing suppliers all in one place.</p>
                <p class="petra_details">
                    Pietra gives you a personalized business plan that you can work through, step-by-step, to launch
                    your business. <br>
                    Get access to workshops, get supplier recommendations, and even finance your first production run.
                </p>
            </div>

            <div class="petra_line">
                <div class="petra_img_line">
                    <img src="/surface/assets/images/plan.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Access low cost order fulfillment, storage, and assembly.</p>
                <p class="petra_details">
                    Save months setting up your warehouse and use Pietra's low cost fulfillment center. Send everything
                    to Pietra and we'll assembly your final product and packaging over zoom and ship it to your
                    customers for you.
                    <br>
                    Fulfillment rates start as low as $1.15/order.
                </p>
            </div>

            <div class="petra_line">
                <div class="petra_img_line">
                    <img src="/surface/assets/images/plan.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Set up & manage multiple sales channels.</p>
                <p class="petra_details">
                    Pietra gives you a personalized business plan that you can work through, step-by-step, to launch
                    your business. <br>
                    Get access to workshops, get supplier recommendations, and even finance your first production run.
                </p>
            </div>



        </div>
    </section>





    <section class="petra_popular_questions">
        <h1 class="ways_petra_text"> Popular Questions </h1>
        <p class="text-center my-4 font3">
            Here's what other people are asking before signing up for Pietra. If you have any questions that aren't <br>
            listed here, please email creators@pietrastudio.com
        </p>

        <div class="container">
            <div id="all_accordion">
                <div class="collapsible-tabs__wrapper">

                    <div class="collapsibles-wrapper">
                        <button type="button" class="collapsible-trigger-btn">
                            Who is Pietra for?
                        </button>
                        <div class="collapsible-content">
                            <div class="collapsible-content__inner">
                                <p>
                                    As all of our paintings, "Cyclone", is hand-made by one of our
                                    artists. High quality oil and acrylic paint and cotton canvas are
                                    used making the painting sturdy, capable of keeping the same color
                                    vibrancy for decades.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="collapsibles-wrapper">
                        <button type="button" class="collapsible-trigger-btn">
                            What tools does Pietra provide beginners?
                        </button>
                        <div class="collapsible-content">
                            <div class="collapsible-content__inner">
                                <p>
                                    We ship all paintings world-wide, free of charge. We are partnered
                                    with major carriers like DHL, UPS, and FedEx. Due to the
                                    hand-painting and drying process, all orders are processed within
                                    10 business days.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="collapsibles-wrapper">
                        <button type="button" class="collapsible-trigger-btn">
                            How can Pietra help me if I already own a business?
                        </button>
                        <div class="collapsible-content">
                            <div class="collapsible-content__inner">
                                <p>
                                    100% Satisfaction Guaranteed. Get a full refund or a painting
                                    re-do if you find that your art piece didn't meet your
                                    expectations, or you were anyhow dissatisfied with it.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="collapsibles-wrapper">
                        <button type="button" class="collapsible-trigger-btn">
                            How does Pietra make launching a product line easier?
                        </button>
                        <div class="collapsible-content">
                            <div class="collapsible-content__inner">
                                <p>
                                    100% Satisfaction Guaranteed. Get a full refund or a painting
                                    re-do if you find that your art piece didn't meet your
                                    expectations, or you were anyhow dissatisfied with it.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="collapsibles-wrapper">
                        <button type="button" class="collapsible-trigger-btn">
                            How does low cost order fulfillment, storage, and assembly work?
                        </button>
                        <div class="collapsible-content">
                            <div class="collapsible-content__inner">
                                <p>
                                    100% Satisfaction Guaranteed. Get a full refund or a painting
                                    re-do if you find that your art piece didn't meet your
                                    expectations, or you were anyhow dissatisfied with it.
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        $(".new_brands").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\vendorSystem\resources\views/surface/pages/new-brands.blade.php ENDPATH**/ ?>