

<?php $__env->startSection('title'); ?>
    Your All Ordered Products | <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .portal_line {
            width: 100%;
            overflow-x: auto;
        }

        .review_text::before {
            content: "Review: ";
            font-weight: bold;
            font-size: 1.125rem;
            display: inherit;
        }

        .review_text {
            margin-bottom: 20px;
        }

        .modal-body {
            text-align: center;
        }
    </style>

    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <div class="col-12 allAlerts">
                            <?php if(session()->has('alertMsg')): ?>
                                <div class="alert text-center <?php echo e(session()->get('type')); ?> alert-dismissible fade show"
                                    role="alert">
                                    <?php echo e(session()->get('alertMsg')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>

                        <h2 class="mb-0 mt-5"> Orders you will receive </h2>

                        <div class="portal_line">


                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Product Name</th>
                                        <th scope="col">Per Unit Price</th>
                                        <th scope="col">Total Units</th>
                                        <th scope="col">Total Cost</th>
                                        <th scope="col">Ordered At</th>
                                        <th scope="col">Delivery Time</th>
                                        <th scope="col">Delivery Status</th>
                                        <th scope="col">View Product</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__empty_1 = true; $__currentLoopData = $ongoing_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td scope="col"><?php echo e($key + 1); ?></td>
                                            <td scope="col"> <img src="<?php echo e($item->prod_image); ?>" alt=""
                                                    class="left_img"></td>
                                            <td scope="col">
                                                <div class="prod_name"><?php echo e($item->prod_name); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">$<?php echo e($item->cost_per_unit); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">$<?php echo e($item->amount); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price"><?php echo e($item->total_cost); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">
                                                    <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->ordered_at)->format('Y-m-d')); ?>

                                                </div>
                                            </td>
                                            <td scope="col">
                                                <div class="delivery_time">
                                                    <?php if($item->delivery_time): ?>
                                                        <?php
                                                            $now = \Carbon\Carbon::now();
                                                            $left_days = $now->diffInDays($item->delivery_time);
                                                        ?>
                                                        <p class="text-danger"><?php echo e($left_days); ?> - Days Left</p>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td scope="col">
                                                <div class="btn btn-sm btn-dark delivery_status">
                                                    <?php echo e($item->delivery_status); ?></div>
                                            </td>
                                            <td scope="col">
                                                <a href="/see-product/<?php echo e($item->product_serial); ?>/<?php echo e($item->prod_cat); ?>/<?php echo e($item->prod_name); ?>"
                                                    class="btn btn-sm btn-primary px-3">View</a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>


                        </div>




                        <h2 class="mb-0 mt-5"> All completed orders for you </h2>

                        <div class="portal_line">


                            <table class="table" id="order_table">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Product Name</th>
                                        <th scope="col">Per Unit Price</th>
                                        <th scope="col">Total Units</th>
                                        <th scope="col">Total Cost</th>
                                        <th scope="col">Ordered At</th>
                                        <th scope="col">Delivered At</th>
                                        <th scope="col">Delivery Status</th>
                                        <th scope="col">Review Order</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__empty_1 = true; $__currentLoopData = $all_completed_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td scope="col"><?php echo e($key + 1); ?></td>
                                            <td scope="col"> <img src="<?php echo e($item->prod_image); ?>" alt=""
                                                    class="left_img"></td>
                                            <td scope="col">
                                                <div class="prod_name"><?php echo e($item->prod_name); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">$<?php echo e($item->cost_per_unit); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">$<?php echo e($item->amount); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price"><?php echo e($item->total_cost); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">
                                                    <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->ordered_at)->format('Y-m-d')); ?>

                                                </div>
                                            </td>
                                            <td scope="col">
                                                <div class="delivery_time">
                                                    <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->delivered_at)->format('Y-m-d')); ?>

                                                </div>
                                            </td>
                                            <td scope="col">
                                                <div class="btn btn-sm btn-dark delivery_status">
                                                    <?php echo e($item->delivery_status); ?></div>
                                            </td>
                                            <td scope="col">
                                                <a href="/review-order/<?php echo e($item->sno); ?>/<?php echo e($item->product_serial); ?>/<?php echo e($item->prod_cat); ?>/<?php echo e($item->prod_name); ?>"
                                                    class="btn btn-sm btn-primary px-3">View</a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>


                        </div>







                        <h2 class="mb-0 mt-5"> Orders you have to deliver </h2>

                        <div class="portal_line">


                            <table class="table" id="order_table2">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Product Name</th>
                                        <th scope="col">Per Unit Price</th>
                                        <th scope="col">Total Units</th>
                                        <th scope="col">Total Cost</th>
                                        <th scope="col">Ordered At</th>
                                        <th scope="col">Delivery Time</th>
                                        <th scope="col">Delivery Status</th>
                                        <th scope="col">Update Order Status</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__empty_1 = true; $__currentLoopData = $orders_to_deliver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td scope="col"><?php echo e($key + 1); ?></td>
                                            <td scope="col"> <img src="<?php echo e($item->prod_image); ?>" alt=""
                                                    class="left_img"></td>
                                            <td scope="col">
                                                <div class="prod_name"><?php echo e($item->prod_name); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">$<?php echo e($item->cost_per_unit); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">$<?php echo e($item->amount); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price"><?php echo e($item->total_cost); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">
                                                    <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->ordered_at)->format('Y-m-d')); ?>

                                                </div>
                                            </td>
                                            <td scope="col">
                                                <div class="delivery_time">
                                                    <?php if($item->delivery_time): ?>
                                                        <?php
                                                            $now = \Carbon\Carbon::now();
                                                            $left_days = $now->diffInDays($item->delivery_time);
                                                        ?>
                                                        <p class="text-danger"><?php echo e($left_days); ?> - Days Left</p>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <form action="/influencer/change-order-status" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="order_serial" value="<?php echo e($item->sno); ?>">
                                                <td scope="col">
                                                    <select name="change_status" class="form-control">
                                                        <option <?php if($item->delivery_status == 'Order confirmed'): ?> selected <?php endif; ?>
                                                            value="Order confirmed">Order confirmed</option>
                                                        <option <?php if($item->delivery_status == 'Picked by courier'): ?> selected <?php endif; ?>
                                                            value="Picked by courier">Picked by courier</option>
                                                        <option <?php if($item->delivery_status == 'On the way'): ?> selected <?php endif; ?>
                                                            value="On the way">On the way</option>
                                                        <option <?php if($item->delivery_status == 'Ready for pickup'): ?> selected <?php endif; ?>
                                                            value="Ready for pickup">Ready for pickup</option>
                                                        <option <?php if($item->delivery_status == 'complete'): ?> selected <?php endif; ?>
                                                            value="complete">Delivered</option>
                                                    </select>
                                                </td>
                                                <td scope="col">
                                                    <center>
                                                        <button class="btn btn-sm btn-primary px-3">Update</button>
                                                    </center>
                                                </td>
                                            </form>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>


                        </div>



                        <h2 class="mb-0 mt-5"> Orders that you delivered </h2>

                        <div class="portal_line">


                            <table class="table" id="order_table3">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Product Name</th>
                                        <th scope="col">Per Unit Price</th>
                                        <th scope="col">Total Units</th>
                                        <th scope="col">Total Cost</th>
                                        <th scope="col">Ordered At</th>
                                        <th scope="col">Delivered At</th>
                                        <th scope="col">See Review</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__empty_1 = true; $__currentLoopData = $delivered_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td scope="col"><?php echo e($key2 + 1); ?></td>
                                            <td scope="col"> <img src="<?php echo e($item->prod_image); ?>" alt=""
                                                    class="left_img"></td>
                                            <td scope="col">
                                                <div class="prod_name"><?php echo e($item->prod_name); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">$<?php echo e($item->cost_per_unit); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">$<?php echo e($item->amount); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price"><?php echo e($item->total_cost); ?></div>
                                            </td>
                                            <td scope="col">
                                                <div class="product_price">
                                                    <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->ordered_at)->format('Y-m-d')); ?>

                                                </div>
                                            </td>
                                            <td scope="col">
                                                <div class="delivery_time">
                                                    <?php if($item->delivered_at != null): ?>
                                                        <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->delivered_at)->format('Y-m-d')); ?>

                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td scope="col">
                                                <button class="btn btn-sm btn-info" data-id="<?php echo e($item->sno); ?>"
                                                    onclick="showReview(this)">Click</button>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>


                        </div>



                    </div>


                </div>





            </div>


        </div>
    </div>



    <!-- Modal -->
    <div class="modal fade" id="review_popup" tabindex="-1" aria-labelledby="review_popupLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="review_popupLabel">See Reviews</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="review_star_icons"></div>
                    <div class="review_text"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".orders").addClass("active");
        let table = new DataTable('#order_table');
        let table2 = new DataTable('#order_table2');
        let table3 = new DataTable('#order_table3');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('influencers.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/influencers/pages/all_orders_status.blade.php ENDPATH**/ ?>