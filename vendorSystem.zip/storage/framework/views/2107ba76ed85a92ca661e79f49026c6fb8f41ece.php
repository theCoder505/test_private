

<?php $__env->startSection('title'); ?>
    Add New Project <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .portal_line {
            padding: 50px;
            border-radius: 15px;
            border: 2px solid #000 !important;
            background: #fff;
        }
    </style>


    <!-- // main webpage content is here  -->
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <div class="col-12 allAlerts">
                            <?php if(session()->has('alertMsg')): ?>
                                <div class="alert text-center <?php echo e(session()->get('type')); ?> alert-dismissible fade show"
                                    role="alert">
                                    <?php echo e(session()->get('alertMsg')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>

                        <h2 class="centered_text"> Add New Project <?php echo e($appname); ?> </h2>

                        <div class="portal_line">

                            <div id="complete_profile">
                                <form action="/menufacturer/add-new-project" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label> Projects Photos </label>
                                        <input type="file" class="form-control" required name="project_photos[]"
                                            accept="image/*" multiple onchange="showMultipleImages(this)">
                                    </div>

                                    <div id="multple_gallery"></div>


                                    <div class="form-group">
                                        <label>Item Name</label>
                                        <input type="text" class="form-control" required name="item_name">
                                    </div>

                                    <div class="form-group">
                                        <label>Describe The Product</label>
                                        <textarea class="form-control" id="comp_bio" name="prod_desc" rows="3" required></textarea>
                                    </div>


                                    <div class="row mt-3">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label> Sample Price (In $) </label>
                                                <input type="number" class="form-control" required name="sample_price">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label> Sample MOQ <small class="text-danger">Input the number of units the
                                                        sample contains. This is usually "1".</small> </label>
                                                <input type="number" class="form-control" required name="sample_moq">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label> What will the Influencer receive? </label>
                                                <input type="text" class="form-control" required name="what_receives">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label> Production Per Unit Cost (In $) </label>
                                                <input type="number" class="form-control" required name="prod_unit_cost">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label> Production MOQ</label>
                                                <input type="number" class="form-control" required name="prod_mcq">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="">Category</label>
                                        <select name="product_category" id="" class="form-control">
                                            <option value="Category Option 1">Category Option 1</option>
                                            <option value="Category Option 2">Category Option 2</option>
                                            <option value="Category Option 3">Category Option 3</option>
                                            <option value="Category Option 4">Category Option 4</option>
                                            <option value="Category Option 5">Category Option 5</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label> Sku Number <small class="text-danger">This is used for your personal item
                                                management and is not visible to your customer.</small> </label>
                                        <input type="number" class="form-control" required name="skunumber">
                                    </div>


                                    <center>
                                        <button class="btn btn-dark px-5">Add Product</button>
                                    </center>

                                </form>
                            </div>

                        </div>



                        <h3 class="headline_text mt-5">
                            All Your <?php echo e($appname); ?> Products
                        </h3>

                        <div class="all_added_projects">
                            <?php $__empty_1 = true; $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="product_line">
                                    <div class="img_holder">
                                        <?php
                                            $images = explode('|', $item->project_photos);
                                            foreach ($images as $key => $imgsrc) {
                                                if ($key < 1) {
                                                    echo '<img src="' . $imgsrc . '" class="prod_img">';
                                                }
                                            }
                                        ?>
                                    </div>
                                    <div class="prod_title"><?php echo e(Str::limit($item->item_name, 150)); ?>...</div>
                                    <a href="/menufacturer/edit-product/<?php echo e($item->sno); ?>" class="btn btn-dark btn-block">
                                        View Product
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h3 class="text-center font-weight-bold text-danger">No Product Yet!</h3>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".products").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('menufacturers.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/menufacturers/pages/products.blade.php ENDPATH**/ ?>