

<?php $__env->startSection('title'); ?>
    Existing Brands - <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <section class="first_section">
        <h1 class="next_gen_capital_text"> One Place to Manageand Scale Your Business. </h1>

        <p class="getup_text">
            Stop managing your business in spreadsheets and email. <br> Streamline your operations with Pietra.
        </p>




        <div class="container my-5">

            <div class="existing_brands affordable">

                <div class="existing_line">
                    <div class="row">
                        <div class="col-8">
                            <p class="place_header">Easier Payments</p>
                            <p class="place_details">Put all your invoices in one place with same day payments for all
                                your vendors, and a 0% service fee when you connect your existing suppliers.</p>
                        </div>
                        <div class="center_items col-4">
                            <img src="/surface/assets/images/existing1.png" alt="" class="place_manage_img">
                        </div>
                    </div>
                </div>

                <div class="existing_line">
                    <div class="row">
                        <div class="col-8">
                            <p class="place_header">Low Cost Fulfillment</p>
                            <p class="place_details">
                                Get free shipping from your factory to a Pietra Fulfillment Center and get pick and pack
                                fees starting at $1.15/order.
                            </p>
                        </div>
                        <div class="center_items col-4">
                            <img src="/surface/assets/images/existing2.png" alt="" class="place_manage_img">
                        </div>
                    </div>
                </div>

                <div class="existing_line">
                    <div class="row">
                        <div class="col-8">
                            <p class="place_header">Better Supplier Management</p>
                            <p class="place_details">
                                Avoid lengthy email chains and allow you and your team to manage conversations from your
                                suppliers in one view.
                            </p>
                        </div>
                        <div class="center_items col-4">
                            <img src="/surface/assets/images/existing3.png" alt="" class="place_manage_img">
                        </div>
                    </div>
                </div>

                <div class="existing_line">
                    <div class="row">
                        <div class="col-8">
                            <p class="place_header">Wholesale & Retail</p>
                            <p class="place_details">
                                List your products on multiple sales channels like Faire, Verishop, and Instagram
                                Shopping and never worry about fulfillment.
                            </p>
                        </div>
                        <div class="center_items col-4">
                            <img src="/surface/assets/images/existing4.png" alt="" class="place_manage_img">
                        </div>
                    </div>
                </div>

                <div class="existing_line">
                    <div class="row">
                        <div class="col-8">
                            <p class="place_header">Easier Asset Management</p>
                            <p class="place_details">
                                Stop sending PDFs over email. Manage all your production assets in one place.
                            </p>
                        </div>
                        <div class="center_items col-4">
                            <img src="/surface/assets/images/existing5.png" alt="" class="place_manage_img">
                        </div>
                    </div>
                </div>

                <div class="existing_line">
                    <div class="row">
                        <div class="col-8">
                            <p class="place_header">Find New Suppliers</p>
                            <p class="place_details">
                                Access 1000+ vetted product and packaging suppliers working with top brands like Gucci,
                                Revolve, and more.
                            </p>
                        </div>
                        <div class="center_items col-4">
                            <img src="/surface/assets/images/existing6.png" alt="" class="place_manage_img">
                        </div>
                    </div>
                </div>

                <div class="existing_line">
                    <div class="row">
                        <div class="col-8">
                            <p class="place_header">Inventory Planning</p>
                            <p class="place_details">
                                Never be out of stock again. Get notified when it’s time to reorder items from your
                                suppliers
                            </p>
                        </div>
                        <div class="center_items col-4">
                            <img src="/surface/assets/images/existing7.png" alt="" class="place_manage_img">
                        </div>
                    </div>
                </div>

                <div class="existing_line">
                    <div class="row">
                        <div class="col-8">
                            <p class="place_header">Manage Special Orders</p>
                            <p class="place_details">
                                Send influencer gifts, create bulk orders for fulfillment, and organize product drops
                                easily.
                            </p>
                        </div>
                        <div class="center_items col-4">
                            <img src="/surface/assets/images/existing8.png" alt="" class="place_manage_img">
                        </div>
                    </div>
                </div>

            </div>

        </div>

        <center>
            <button class="startFreeBtn" onclick="showSignUp()">Create Free Account</button>
        </center>


    </section>




    <section class="petra_ways">
        <h1 class="ways_petra_text"> Ways To Use Pietra </h1>

        <div class="grid_petra">

            <div class="petra_line">
                <div class="text-center">
                    <img src="/surface/assets/images/petra1.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Launch New Product Lines</p>
                <p class="petra_details">
                    Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                    design products and packaging.
                </p>
                <p class="petra_red">
                    "It's like Alibaba, but better, safer, and easier to use."
                </p>
            </div>

            <div class="petra_line">
                <div class="text-center">
                    <img src="/surface/assets/images/petra2.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Streamline Your Fulfillment</p>
                <p class="petra_details">
                    Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                    design products and packaging.
                </p>
                <p class="petra_red">
                    "It's like Alibaba, but better, safer, and easier to use."
                </p>
            </div>

            <div class="petra_line">
                <div class="text-center">
                    <img src="/surface/assets/images/petra3.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Scale & Manage Your Operations</p>
                <p class="petra_details">
                    Use our vetted supplier network of 1000+ private label and contract manufacturers to source and
                    design products and packaging.
                </p>
                <p class="petra_red">
                    "It's like Alibaba, but better, safer, and easier to use."
                </p>
            </div>



        </div>
    </section>




    <section class="smartest_operator">
        <h1 class="next_gen_capital_text"> For The Smartest eCommerce Operators </h1>
        <div class="container">

            <div class="row ecomLine">
                <div class="center_items col-md-6">
                    <div class="text_holder">
                        <h1 class="ecom_header">
                            Looking for suppliers? From merch to custom manufacturers,it's all here.
                        </h1>
                        <p class="ecom_para">
                            Access hand-picked, high-quality suppliers specializing in 50+ product categories. If you
                            can
                            dream it, you can source it on Pietra.
                        </p>
                        <p class="ecom_para last_para">
                            <b>Pro Tip:</b> Pietra is the most affordable way to pay your suppliers. Save 5-10% in fees
                            when
                            you invite and pay your existing suppliers.
                        </p>

                        <a href="/" class="btn learnmorebtn">Learn More → </a>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="/surface/assets/images/ecom1.png" alt="" class="ecomImage">
                </div>
            </div>

            <div class="row ecomLine">
                <div class="col-md-6">
                    <img src="/surface/assets/images/ecom2.png" alt="" class="ecomImage">
                </div>
                <div class="center_items col-md-6">
                    <div class="text_holder">
                        <h1 class="ecom_header">
                            Looking for suppliers? From merch to custom manufacturers,it's all here.
                        </h1>
                        <p class="ecom_para">
                            Access hand-picked, high-quality suppliers specializing in 50+ product categories. If you
                            can
                            dream it, you can source it on Pietra.
                        </p>
                        <p class="ecom_para last_para">
                            <b>Pro Tip:</b> Pietra is the most affordable way to pay your suppliers. Save 5-10% in fees
                            when
                            you invite and pay your existing suppliers.
                        </p>

                        <a href="/" class="btn learnmorebtn">Learn More → </a>
                    </div>
                </div>
            </div>

            <div class="row ecomLine">
                <div class="center_items col-md-6">
                    <div class="text_holder">
                        <h1 class="ecom_header">
                            Looking for suppliers? From merch to custom manufacturers,it's all here.
                        </h1>
                        <p class="ecom_para">
                            Access hand-picked, high-quality suppliers specializing in 50+ product categories. If you
                            can
                            dream it, you can source it on Pietra.
                        </p>
                        <p class="ecom_para last_para">
                            <b>Pro Tip:</b> Pietra is the most affordable way to pay your suppliers. Save 5-10% in fees
                            when
                            you invite and pay your existing suppliers.
                        </p>

                        <a href="/" class="btn learnmorebtn">Learn More → </a>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="/surface/assets/images/ecom3.png" alt="" class="ecomImage">
                </div>
            </div>

            <div class="row ecomLine">
                <div class="col-md-6">
                    <img src="/surface/assets/images/ecom4.png" alt="" class="ecomImage">
                </div>
                <div class="center_items col-md-6">
                    <div class="text_holder">
                        <h1 class="ecom_header">
                            Looking for suppliers? From merch to custom manufacturers,it's all here.
                        </h1>
                        <p class="ecom_para">
                            Access hand-picked, high-quality suppliers specializing in 50+ product categories. If you
                            can
                            dream it, you can source it on Pietra.
                        </p>
                        <p class="ecom_para last_para">
                            <b>Pro Tip:</b> Pietra is the most affordable way to pay your suppliers. Save 5-10% in fees
                            when
                            you invite and pay your existing suppliers.
                        </p>

                        <a href="/" class="btn learnmorebtn">Learn More → </a>
                    </div>
                </div>
            </div>

        </div>
    </section>



    <section class="all_reviews">
        <h1 class="ways_petra_text"> The Reviews Are In </h1>

        <div class="container">

            <div id="all_review_lines" class="owl-carousel owl-theme">

                <div class="item review_line">
                    <div class="left_part">
                        <p class="left_header">FORM by Sami Clarke</p>
                        <p class="left_details">
                            We have absolutely loved working with Pietra! Their suppliers are top tier, customer service
                            is
                            exceptional and they make operating a storefront extremely simple.
                        </p>
                    </div>
                    <div class="right_part">
                        <img src="/surface/assets/images/review1.jpg" alt="" class="right_part_img">
                    </div>
                </div>

                <div class="item review_line">
                    <div class="left_part">
                        <p class="left_header">FORM by Sami Clarke 2</p>
                        <p class="left_details">
                            We have absolutely loved working with Pietra! Their suppliers are top tier, customer service
                            is
                            exceptional and they make operating a storefront extremely simple.
                        </p>
                    </div>
                    <div class="right_part">
                        <img src="/surface/assets/images/review1.jpg" alt="" class="right_part_img">
                    </div>
                </div>

                <div class="item review_line">
                    <div class="left_part">
                        <p class="left_header">FORM by Sami Clarke 3</p>
                        <p class="left_details">
                            We have absolutely loved working with Pietra! Their suppliers are top tier, customer service
                            is
                            exceptional and they make operating a storefront extremely simple.
                        </p>
                    </div>
                    <div class="right_part">
                        <img src="/surface/assets/images/review1.jpg" alt="" class="right_part_img">
                    </div>
                </div>

                <div class="item review_line">
                    <div class="left_part">
                        <p class="left_header">FORM by Sami Clarke 4</p>
                        <p class="left_details">
                            We have absolutely loved working with Pietra! Their suppliers are top tier, customer service
                            is
                            exceptional and they make operating a storefront extremely simple.
                        </p>
                    </div>
                    <div class="right_part">
                        <img src="/surface/assets/images/review1.jpg" alt="" class="right_part_img">
                    </div>
                </div>

            </div>

        </div>


        <center>
            <button class="startFreeBtn mt-5" onclick="showSignUp()">Start For Free</button>
        </center>

    </section>




    <section class="petra_ways">
        <h1 class="ways_petra_text"> One Subscription Gives You Access To </h1>

        <div class="grid_petra_4">

            <div class="petra_line">
                <div class="petra_img_line">
                    <img src="/surface/assets/images/plan.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Get your own personalized business plan.</p>
                <p class="petra_details">
                    Pietra gives you a personalized business plan that you can work through, step-by-step, to launch
                    your business. <br>
                    Get access to workshops, get supplier recommendations, and even finance your first production run.
                </p>
            </div>

            <div class="petra_line">
                <div class="petra_img_line">
                    <img src="/surface/assets/images/plan.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Find new suppliers and manage existing suppliers all in one place.</p>
                <p class="petra_details">
                    Pietra gives you a personalized business plan that you can work through, step-by-step, to launch
                    your business. <br>
                    Get access to workshops, get supplier recommendations, and even finance your first production run.
                </p>
            </div>

            <div class="petra_line">
                <div class="petra_img_line">
                    <img src="/surface/assets/images/plan.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Access low cost order fulfillment, storage, and assembly.</p>
                <p class="petra_details">
                    Save months setting up your warehouse and use Pietra's low cost fulfillment center. Send everything
                    to Pietra and we'll assembly your final product and packaging over zoom and ship it to your
                    customers for you.
                    <br>
                    Fulfillment rates start as low as $1.15/order.
                </p>
            </div>

            <div class="petra_line">
                <div class="petra_img_line">
                    <img src="/surface/assets/images/plan.png" alt="" class="petra_img">
                </div>
                <p class="petra_heading">Set up & manage multiple sales channels.</p>
                <p class="petra_details">
                    Pietra gives you a personalized business plan that you can work through, step-by-step, to launch
                    your business. <br>
                    Get access to workshops, get supplier recommendations, and even finance your first production run.
                </p>
            </div>



        </div>
    </section>





    <section class="petra_popular_questions">
        <h1 class="ways_petra_text"> Popular Questions </h1>
        <p class="text-center my-4 font3">
            Here's what other people are asking before signing up for Pietra. If you have any questions that aren't <br>
            listed here, please email creators@pietrastudio.com
        </p>

        <div class="container">
            <div id="all_accordion">
                <div class="collapsible-tabs__wrapper">

                    <div class="collapsibles-wrapper">
                        <button type="button" class="collapsible-trigger-btn">
                            Who is Pietra for?
                        </button>
                        <div class="collapsible-content">
                            <div class="collapsible-content__inner">
                                <p>
                                    As all of our paintings, "Cyclone", is hand-made by one of our
                                    artists. High quality oil and acrylic paint and cotton canvas are
                                    used making the painting sturdy, capable of keeping the same color
                                    vibrancy for decades.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="collapsibles-wrapper">
                        <button type="button" class="collapsible-trigger-btn">
                            What tools does Pietra provide beginners?
                        </button>
                        <div class="collapsible-content">
                            <div class="collapsible-content__inner">
                                <p>
                                    We ship all paintings world-wide, free of charge. We are partnered
                                    with major carriers like DHL, UPS, and FedEx. Due to the
                                    hand-painting and drying process, all orders are processed within
                                    10 business days.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="collapsibles-wrapper">
                        <button type="button" class="collapsible-trigger-btn">
                            How can Pietra help me if I already own a business?
                        </button>
                        <div class="collapsible-content">
                            <div class="collapsible-content__inner">
                                <p>
                                    100% Satisfaction Guaranteed. Get a full refund or a painting
                                    re-do if you find that your art piece didn't meet your
                                    expectations, or you were anyhow dissatisfied with it.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="collapsibles-wrapper">
                        <button type="button" class="collapsible-trigger-btn">
                            How does Pietra make launching a product line easier?
                        </button>
                        <div class="collapsible-content">
                            <div class="collapsible-content__inner">
                                <p>
                                    100% Satisfaction Guaranteed. Get a full refund or a painting
                                    re-do if you find that your art piece didn't meet your
                                    expectations, or you were anyhow dissatisfied with it.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="collapsibles-wrapper">
                        <button type="button" class="collapsible-trigger-btn">
                            How does low cost order fulfillment, storage, and assembly work?
                        </button>
                        <div class="collapsible-content">
                            <div class="collapsible-content__inner">
                                <p>
                                    100% Satisfaction Guaranteed. Get a full refund or a painting
                                    re-do if you find that your art piece didn't meet your
                                    expectations, or you were anyhow dissatisfied with it.
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        $(".exstngbrands").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\vendorSystem\resources\views/surface/pages/existing-brands.blade.php ENDPATH**/ ?>