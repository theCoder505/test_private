

<?php $__env->startSection('title'); ?>
    Welcome To <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- // main webpage content is here  -->
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <h2 class="centered_text">Welcome back to <?php echo e($appname); ?> </h2>

                        <div class="portal_line">
                            <h3 class="headline_text">
                                Get started with <?php echo e($appname); ?>

                            </h3>

                            <div class="item_grid_5">


                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/training.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Training Module</p>
                                    <p class="item_desc">Learn how to use the Partner Portal to find
                                        customers and...</p>
                                    <center>
                                        <a href="/link" class="continue_btn">Continue Reading</a>
                                    </center>
                                </div>

                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/bill.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Invoicing & Fulfillment</p>
                                    <p class="item_desc">Learn how to properly invoice and fulfill
                                        Creator
                                        orders.</p>
                                    <center>
                                        <a href="/link" class="continue_btn">Continue Reading</a>
                                    </center>
                                </div>

                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/guide.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Receiving Guidelines</p>
                                    <p class="item_desc">Review how to ship products to Pietra's
                                        Fulfillment Center...</p>
                                    <center>
                                        <a href="/link" class="continue_btn">Continue Reading</a>
                                    </center>
                                </div>

                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/profile_avatar_man.png')); ?>"
                                            alt="" class="item_img">
                                    </div>
                                    <p class="item_title">Set Up Business Profile</p>
                                    <p class="item_desc">Describe your business and its private label
                                        and...
                                    </p>
                                    <center>
                                        <a href="/link" class="continue_btn">Continue Reading</a>
                                    </center>
                                </div>

                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/request-payment.png')); ?>"
                                            alt="" class="item_img">
                                    </div>
                                    <p class="item_title">Set Up Direct Deposit</p>
                                    <p class="item_desc">Allow Creators to send you money for each
                                        order...
                                    </p>
                                    <center>
                                        <a href="/link" class="continue_btn">Continue Reading</a>
                                    </center>
                                </div>



                            </div>
                        </div>



                        <div class="portal_line">
                            <h3 class="headline_text">
                                Keeping Up With Customers
                            </h3>

                            <div class="item_grid_5">


                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/messages.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Your Customer Messages</p>
                                    <p class="item_desc">Reply Customers Soon...</p>
                                    <center>
                                        <a href="/link" class="continue_btn">Continue</a>
                                    </center>
                                </div>

                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/orders.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Orders & Shipments</p>
                                    <p class="item_desc">Track Your Orders</p>
                                    <center>
                                        <a href="/link" class="continue_btn">Continue</a>
                                    </center>
                                </div>


                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/status.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Announcements</p>
                                    <p class="item_desc">Set your current announce...</p>
                                    <center>
                                        <a href="/link" class="continue_btn">Continue</a>
                                    </center>
                                </div>

                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/auto-reply.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Auto Reply Message</p>
                                    <p class="item_desc">Set an auto reply Message</p>
                                    <center>
                                        <a href="/link" class="continue_btn">Continue</a>
                                    </center>
                                </div>

                            </div>
                        </div>


                        <div class="portal_line">
                            <h3 class="headline_text">
                                Find New Customers
                            </h3>

                            <div class="item_grid_5">


                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/links.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">share Your Profile</p>
                                    <br>
                                    <center>
                                        <button class="continue_btn copy_link" onclick="copy_link(this)">Copy
                                            Link</button>
                                    </center>
                                </div>

                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/links.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Share Your Catalog</p>
                                    <br>
                                    <center>
                                        <button class="continue_btn copy_link" onclick="copy_link(this)">Copy
                                            Link</button>
                                    </center>
                                </div>

                            </div>
                        </div>


                        <div class="portal_line">
                            <h3 class="headline_text">
                                How To Videos - <?php echo e($appname); ?>

                            </h3>

                            <div class="item_grid_5">


                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="total_center">
                                    <a href="/2" class="centered_watch_text">View All</a>
                                </div>



                            </div>
                        </div>

                    </div>
                </div>

                <div id="styleSelector">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".home").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('menufacturers.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\vendorSystem\resources\views/menufacturers/pages/dashboard.blade.php ENDPATH**/ ?>