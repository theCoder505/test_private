// slick carousel of interprenuer slider 
$('#interpreneur').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 0,
    speed: 4000,
    pauseOnHover: false,
    cssEase: 'linear'
});




$('#company_sliders').owlCarousel({
    loop: true,
    margin: 50,
    nav: true,
    autoplay: true,
    autoplayTimeout: 5000,
    autoplayHoverPause: true,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 2
        },
        1000: {
            items: 4
        }
    }
});


$('#all_review_lines').owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    autoplay: true,
    autoplayTimeout: 50000,
    autoplayHoverPause: true,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 2
        },
        1000: {
            items: 3
        }
    }
})




function showSignUp() {

}


function activeTab(passedParam) {
    let dataId = $(passedParam).attr("data-id");
    $(".select_type").removeClass("tab_active");
    $(passedParam).addClass("tab_active");
    $(".tabline_data").addClass("d-none");
    $(".tabline_data:nth-child(" + dataId + ")").removeClass("d-none");
}



function showDoing(passedParam) {
    let dataId = $(passedParam).attr("data-id");
    $(".doing_tab").removeClass("doing_active");
    $(passedParam).addClass("doing_active");
    $(".doing_img").addClass("d-none");
    $(".doing_img:nth-child(" + dataId + ")").removeClass("d-none");
}



function changeImg(passedThis) {
    let dataImg = $(passedThis).attr("data-hover");
    $(passedThis).attr("src", dataImg);
}


function defaultImg(passedThis) {
    let dataImg = $(passedThis).attr("data-main");
    $(passedThis).attr("src", dataImg);
}




const collapsibleButtons = document.querySelectorAll(
    ".collapsible-trigger-btn"
);

collapsibleButtons.forEach((collapsibleButton) => {
    const collapsibleContentDataHeight =
        collapsibleButton.nextElementSibling.offsetHeight;
    collapsibleButton.nextElementSibling.style.height = 0;
    collapsibleButton.addEventListener("click", (e) => {
        if (
            !e.currentTarget.parentElement.classList.contains("collapsible-tab__open")
        ) {
            e.currentTarget.parentElement.classList.toggle("collapsible-tab__open");
            e.currentTarget.nextElementSibling.style.height = `${collapsibleContentDataHeight}px`;
        } else {
            e.currentTarget.parentElement.classList.remove("collapsible-tab__open");
            e.currentTarget.nextElementSibling.style.height = 0;
        }
    });
});




$(".see_more_less").click(function () {
    if ($(".grid_petra_4_lines").hasClass("d-none")) {
        $(".grid_petra_4_lines").removeClass("d-none");
        $(this).html("See Less")
    } else {
        $(".grid_petra_4_lines").addClass("d-none");
        $(this).html("See More")
    }
});


function showPosts(passedThis) {
    let dataId = $(passedThis).attr("data-id");

    if (dataId == 'all') {
        $(".blog_item").removeClass("d-none");
    } else {
        $(".blog_item").addClass("d-none");
        $(".blog-container ." + dataId).removeClass("d-none");
    }
    $(".post_tabline").removeClass("active_line");
    $('[data-id="' + dataId + '"]').addClass("active_line");
}






var firstImgSrc = $(".signup_sideimg").attr("src");
var SecondImgSrc = $(".signup_sideimg").attr("data-id");

function activateForm(passedThis) {
    if (passedThis == 'login') {
        $(".signup_sideimg").attr("src", SecondImgSrc);
        $(".login_form").removeClass("d-none");
        $(".forget_pwd").addClass("d-none");
    } else {
        $(".signup_sideimg").attr("src", firstImgSrc);
        $(".signup_main_form").removeClass("d-none");
    }

    $(".sign_tabline").removeClass("activated_line");
    $("#" + passedThis).addClass("activated_line");
    $(".user_login_common").addClass("d-none");
    $("." + passedThis).removeClass("d-none");

    $(".login_signup_text").html(passedThis);
}



$(".forget_pwd_text").click(function () {
    $(".login_form").addClass("d-none");
    $(".forget_pwd").removeClass("d-none");
    $(".login_signup_text").html("Forget Password");
    $(".sign_tabline").removeClass("activated_line");
});








// forget password sending otp to user
$(".forgetPwdBtn").click(function (event) {
    event.preventDefault();
    let csrfToken = $("._token").val();
    let user_type = $(".forget_user_acc_type").val();
    let email_addr_length = $(".forget_email_addr").val().length;
    let email_addr = ($(".forget_email_addr").val()).trim();



    if (email_addr_length > 0) {
        $(".alertBox").addClass("d-none");
        $(".forgetPwdBtn").html('<div class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>');

        $.ajax({
            method: "POST",
            url: "/send-otp-to-forget-pwd",
            data: {
                type: user_type,
                user_email: email_addr,
                _token: csrfToken,
            }
        })
            .done(function (response) {
                if (response == 'otp sent') {
                    $(".forget_pwd_setup").removeClass("d-none");
                    $(".forgetPwdBtn").html("Send 6 Digit OTP");
                    $(".forgetPwdBtn").addClass("d-none");
                }
                else if (response == 'nouser') {
                    $(".alertBox").removeClass("d-none");
                    $(".alertBox").html("No Such User Found");
                    $(".forgetPwdBtn").html("Send 6 Digit OTP");
                }
                else {
                    $(".alertBox").addClass("d-none");
                    $(".alertBox").html("Error Occured");
                }
            });


    } else {
        $(".alertBox").removeClass("d-none");
        $(".alertBox").html("All Fields Are Required");
    }
});








// checking with otp 
$(".checkOtpSubmit").click(function (event) {
    event.preventDefault();
    let csrfToken = $("._token").val();
    let user_type = $(".forget_user_acc_type").val();
    let email_addr = ($(".forget_email_addr").val()).trim();
    let email_addr_length = $(".forget_email_addr").val().length;
    let typed_otp = ($(".typed_otp").val()).trim();
    let typed_otp_length = $(".typed_otp").val().length;
    let new_password = ($(".new_password").val()).trim();
    let new_pwd_length = $(".new_password").val().length;



    if (email_addr_length > 0 && new_pwd_length > 0 && typed_otp_length > 0) {
        $(".sucessAlertBox").addClass("d-none");
        $(".alertBox").addClass("d-none");
        $(".checkOtpSubmit").html('<div class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>');

        $.ajax({
            method: "POST",
            url: "/check-forget-pwd-otp",
            data: {
                user_type: user_type,
                email_addr: email_addr,
                typed_otp: typed_otp,
                new_password: new_password,
                _token: csrfToken,
            }
        })
            .done(function (response) {
                $(".checkOtpSubmit").html('Send 6 Digit OTP');
                if (response == 'matched') {
                    $(".sucessAlertBox").removeClass("d-none");
                    $(".sucessAlertBox").html("Passwords Been Updated. You can login now.");
                }
                else if (response == 'missmatch') {
                    $(".alertBox").removeClass("d-none");
                    $(".alertBox").html("OTP not matched. Try Again!");
                }
                else if (response == 'nouser') {
                    $(".alertBox").removeClass("d-none");
                    $(".alertBox").html("No Such User Found");
                }
                else {
                    $(".alertBox").addClass("d-none");
                    $(".alertBox").html("Error Occured");
                }
            });


    } else {
        $(".alertBox").removeClass("d-none");
        $(".alertBox").html("All Fields Are Required");
    }
});










// login user 
$(".loginUser").click(function (event) {
    event.preventDefault();
    let csrfToken = $("._token").val();
    let user_type = $(".login_acc_type").val();
    let email_addr = ($(".login_email_addr").val()).trim();
    let email_addr_length = $(".login_email_addr").val().length;
    let login_pwd = ($(".login_pwd").val()).trim();
    let login_pwd_length = $(".login_pwd").val().length;



    if (email_addr_length > 0 && login_pwd_length > 0) {
        $(".alertBox").addClass("d-none");
        $(".loginUser").html('<div class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>');

        $.ajax({
            method: "POST",
            url: "/sign-in-existing-user",
            data: {
                user_type: user_type,
                email_addr: email_addr,
                login_pwd: login_pwd,
                _token: csrfToken,
            }
        })
            .done(function (response) {
                if (response == 'success') {
                    //    send to dashboard 
                    window.location.href = "/" + user_type + "/dashboard";
                }
                else {
                    $(".checkOtpSubmit").addClass("d-none");
                    $(".alertBox").removeClass("d-none");
                    $(".alertBox").html(response);
                    $(".loginUser").html('LOGIN');
                }
            });


    } else {
        $(".alertBox").removeClass("d-none");
        $(".alertBox").html("All Fields Are Required");
    }
});











// signup user and send otp
$(".submitButton").click(function (event) {
    event.preventDefault();
    let csrfToken = $("._token").val();

    let user_acc_type = ($(".user_acc_type").val()).trim();
    let user_acc_type_len = $(".user_acc_type").val().length;

    let acc_name = ($(".acc_name").val()).trim();
    let acc_name_len = $(".acc_name").val().length;

    let full_name = ($(".full_name").val()).trim();
    let full_name_len = $(".full_name").val().length;

    let email_addr = ($(".email_addr").val()).trim();
    let email_addr_len = $(".email_addr").val().length;

    let user_pwd = ($(".user_pwd").val()).trim();
    let user_pwd_len = $(".user_pwd").val().length;


    if ((user_acc_type_len == 0) || (acc_name_len == 0) || (full_name_len == 0) || (email_addr_len == 0) || (user_pwd_len == 0)) {
        $(".alertBox").removeClass("d-none");
        $(".alertBox").html("All Fields Are Required");
    } else {
        $(".alertBox").addClass("d-none");
        $(".submitButton").html('<div class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>');

        $.ajax({
            method: "POST",
            url: "/add-new-user-with-otp",
            data: {
                user_acc_type: user_acc_type,
                acc_name: acc_name,
                full_name: full_name,
                email_addr: email_addr,
                user_pwd: user_pwd,
                _token: csrfToken,
            }
        })
            .done(function (response) {
                $(".submitButton").html('SUBMIT');
                if (response == 'success') {
                    $(".alertBox").addClass("d-none");
                    $(".six_digit_otp_part").removeClass("d-none");
                    $(".signup_main_form").addClass("d-none");
                } else {
                    $(".alertBox").removeClass("d-none");
                    $(".alertBox").html(response);
                }

            });
    }


});














$(".signupButton").click(function (event) {
    event.preventDefault();
    let csrfToken = $("._token").val();

    let user_acc_type = ($(".user_acc_type").val()).trim();
    let email_addr = ($(".email_addr").val()).trim();
    let user_otp = ($(".user_otp").val()).trim();

    $.ajax({
        method: "POST",
        url: "/check-user-otp-and-add-user",
        data: {
            user_acc_type: user_acc_type,
            email_addr: email_addr,
            user_otp: user_otp,
            _token: csrfToken,
        }
    })
        .done(function (response) {
            if (response == 'matched') {
                $(".alertBox").addClass("d-none");
                $(".six_digit_otp_part").addClass("d-none");
                $(".sucessAlertBox").removeClass("d-none");
                $(".signup form")[0].reset();
                $(".sucessAlertBox").html("OTP Matched! Welcome To Our System, you can login now!");
            } else {
                $(".alertBox").removeClass("d-none");
                $(".alertBox").html("OTP NOT Matched! Try again!");
            }
        });
});