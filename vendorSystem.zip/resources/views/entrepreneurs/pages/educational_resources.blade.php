@extends('entrepreneurs.layouts.app')

@section('title')
    Educational Resources {{ $appname }}
@endsection

@section('content')
    <!-- // main webpage content is here  -->
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <h2 class="centered_text">Learn About {{ $appname }} </h2>

                        <div class="portal_line">
                            <h3 class="headline_text">
                                How To Videos - {{ $appname }}
                            </h3>

                            <div class="item_grid_5">


                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>
                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>
                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>
                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>

                                <div class="item_grid video_grid">
                                    <div class="video_holder">
                                        <iframe width="942" height="530" class="iframe_video"
                                            src="https://www.youtube.com/embed/6wmXsIPDH5I"
                                            title="The Real Life Of A Software Engineer (Seattle)" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                    </div>
                                    <p class="item_title">Welcome to the Pietra Partner Portal (pt. 1)
                                    </p>
                                    <p class="item_desc">Learn about the modules and functions of the
                                        Pietra Partner Portal.</p>
                                    <center>
                                        <button class="continue_btn" onclick="watchIt(this)"
                                            data-id="1">Watch</button>
                                    </center>
                                </div>



                            </div>
                        </div>

                    </div>
                </div>

                <div id="styleSelector">

                </div>
            </div>
        </div>
    </div>
@endsection


@section('scripts')
    <script>
        $(".resources").addClass("active");
    </script>
@endsection
