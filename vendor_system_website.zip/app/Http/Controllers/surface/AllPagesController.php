<?php

namespace App\Http\Controllers\surface;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\DB;

class AllPagesController extends Controller
{





    public function showHomePage()
    {
        $homepageData = DB::table('homepage_data')->where('sno', 1)->get();
        $enterprenuer_profiles = DB::table('vendor_profile')->where('vendor_type', 'entrepreneur')->orderByDesc('serial')->get();
        $influencer_profiles = DB::table('vendor_profile')->where('vendor_type', 'influencer')->orderByDesc('serial')->get();
        return view('surface.pages.home', compact('homepageData', 'enterprenuer_profiles', 'influencer_profiles'));
    }





    public function readBlogsPage()
    {
        $blo_cats = DB::table('categories')->where('cat_type', 'blog')->orderByDesc('sno')->get();
        $blog_data = DB::table('blogs')->orderByDesc('sno')->get();
        return view('surface.pages.blogs', compact('blo_cats', 'blog_data'));
    }



    public function readParticularBlog($serial, $category, $title)
    {
        $blog_data = DB::table('blogs')->where('sno', $serial)->get();
        $related_blogs = DB::table('blogs')->where('blog_category', $category)->orderByDesc('sno')->where('sno', '!=', $serial)->get();
        return view('surface.pages.specific_blog', compact('related_blogs', 'blog_data'));
    }





    public function esictingBrnadsPage()
    {
        $allfaqs = DB::table('faqs')->orderByDesc('sno')->get();
        $brand_data = DB::table('brand_section_data')->where('sno', 1)->get();
        $rest_data = DB::table('brand_rest_section_data')->where('sno', 1)->get();
        return view('surface.pages.existing-brands', compact('allfaqs', 'brand_data', 'rest_data'));
    }





    public function redirect_to_spec_user($user_uid)
    {
        if ((Cookie::get('loggertype'))) {
            $loggertype = (Cookie::get('loggertype'));
            $loggerUniqueId = (Cookie::get('loggerUniqueId'));

            if ($loggertype == 'menufacturer') {
                // return redirect('/see-vendor-profile/menufacturer/' . $user_uid);
                return redirect('/menufacturer/dashboard');
            }
            if ($loggertype == 'entrepreneur') {
                return redirect('/entrepreneur/dashboard');
            } else {
                return redirect('/influencer/dashboard');
            }
        } else {
            return '/sign-in';
        }
    }










    public function newBrandsPage()
    {
        $brand_data = DB::table('brand_section_data')->where('sno', 1)->get();
        $rest_data = DB::table('brand_rest_section_data')->where('sno', 1)->get();
        $allfaqs = DB::table('faqs')->orderByDesc('sno')->get();
        return view('surface.pages.new-brands', compact('allfaqs', 'brand_data', 'rest_data'));
    }







    public function showSpecPageData($pagetype)
    {

        if ($pagetype == 'terms-conditions') {
            $type = 'Our Terms & Conditions';
            $data = DB::table('more_page_data')->where('page_name', 'terms')->value('page_text');
        }

        if ($pagetype == 'privacy-policy') {
            $type = 'Our Privacy & Policies';
            $data = DB::table('more_page_data')->where('page_name', 'privacy')->value('page_text');
        }

        return view('surface.pages.more_page', compact('type', 'data'));
    }












    //
}
