@extends('surface.layouts.app')

@section('title')
    Read Our Posts | {{ $appname }}
@endsection



@section('content')
    <style>
        .blog_small_desc {
            text-transform: capitalize;
        }
    </style>


    <div class="all_post_tablines">
        <div class="post_tabline active_line" data-id="all" onclick="showPosts(this)"> All Posts </div>
        @forelse ($blo_cats as $key => $category)
            <div class="post_tabline" data-id="{{ $category->category_name }}" onclick="showPosts(this)">
                {{ $category->category_name }} </div>
        @empty
        @endforelse
    </div>


    <div class="blog-container">


        @forelse ($blog_data as $key2 => $blog)
            <div class="blog_item" data-class="{{ $blog->blog_category }}">
                <img src="{{ $blog->blog_image }}" alt="" class="blog_img">
                <div class="blog_detail_part">
                    <h2 class="blog_title">
                        {{ $blog->blog_title }}
                    </h2>
                    <div class="blog_time">
                        {{ date('F d, Y', strtotime($blog->time)) }}
                    </div>
                    <p class="blog_small_desc">
                        {{ substr($blog->blog_description, 0, 100) }}...
                    </p>
                    <a class="read_more_blog"
                        href="/see-blog/{{ $blog->sno }}/{{ $blog->blog_category }}/{{ $blog->blog_title }}">
                        Read More
                    </a>
                </div>
            </div>

        @empty
        @endforelse


    </div>
@endsection



@section('scripts')
    <script>
        $(".blogs").addClass("active");
    </script>
@endsection
