<footer class="footer_section">

</footer><?php /**PATH C:\xampp\htdocs\Laravel\vendorSystem\resources\views/surface/layouts/footer.blade.php ENDPATH**/ ?>