

<?php $__env->startSection('title'); ?>
    Read Particular Blog From - <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <style>
        .blog_item:nth-child(5n+1),
        .blog_item:nth-child(1) {
            grid-column: unset;
        }

        .blog-container {
            padding: 50px 0px;
            max-width: unset;
            margin: 0px auto;
            display: grid;
            grid-gap: 20px;
            grid-template-columns: repeat(3, 1fr);
        }
    </style>

    <div class="container my-5">

        <?php $__empty_1 = true; $__currentLoopData = $blog_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <img src="<?php echo e($blog->blog_image); ?>" alt="" class="blog_thumbnail_img">

            <div class="blog_time mt-3">Updated At: <?php echo e(date('F d, Y', strtotime($blog->time))); ?> </div>
            <div class="blog_title"><?php echo e($blog->blog_title); ?> </div>

            <pre class="blog_main_details"><?php echo $blog->blog_description; ?></pre>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>




        <div class="more_related_blogs mt-5 pt-5">
            <h2 class="font-weight-bold">
                More Related Blogs
            </h2>


            <div class="blog-container">


                <?php $__empty_1 = true; $__currentLoopData = $related_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="blog_item" data-class="<?php echo e($blog->blog_category); ?>">
                        <img src="<?php echo e($blog->blog_image); ?>" alt="" class="blog_img">
                        <div class="blog_detail_part">
                            <h2 class="blog_title">
                                <?php echo e($blog->blog_title); ?>

                            </h2>
                            <div class="blog_time">
                                <?php echo e(date('F d, Y', strtotime($blog->time))); ?>

                            </div>
                            <p class="blog_small_desc">
                                <?php echo e(substr($blog->blog_description, 0, 100)); ?>...
                            </p>
                            <a class="read_more_blog"
                                href="/see-blog/<?php echo e($blog->sno); ?>/<?php echo e($blog->blog_category); ?>/<?php echo e($blog->blog_title); ?>">
                                Read More
                            </a>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        $(".blogs").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/surface/pages/specific_blog.blade.php ENDPATH**/ ?>