

<?php $__env->startSection('title'); ?>
    Setup Your Profile At <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .portal_line {
            padding: 50px;
            border-radius: 15px;
            border: 2px solid #000 !important;
            background: #fff;
        }
    </style>


    <!-- // main webpage content is here  -->
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <div class="col-12 allAlerts">
                            <?php if(session()->has('alertMsg')): ?>
                                <div class="alert text-center <?php echo e(session()->get('type')); ?> alert-dismissible fade show"
                                    role="alert">
                                    <?php echo e(session()->get('alertMsg')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>

                        <h2 class="centered_text"> Setup Your Profile At <?php echo e($appname); ?> </h2>

                        <div class="portal_line">
                            <h3 class="headline_text">
                                Complete Your <?php echo e($appname); ?> Profile
                            </h3>


                            <?php $__empty_1 = true; $__currentLoopData = $vendor_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $company_logo = $item->company_logo;
                                    $business_name = $item->business_name;
                                    $comp_bio = $item->comp_bio;
                                    $pdf_file = $item->pdf_file;
                                    $phone_number = $item->phone_number;
                                    $partner_account = $item->partner_account;
                                    $attributes = $item->attributes;
                                    $country = $item->country;
                                    $state = $item->state;
                                    $create_n_ship_time = $item->create_n_ship_time;
                                    $typical_run_time = $item->typical_run_time;
                                    $avg_yearly_sales = $item->avg_yearly_sales;
                                    $notable_projects = $item->notable_projects;
                                    $project_gallery = $item->project_gallery;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php
                                    $company_logo = asset('vendor/assets/images/user.jpg');
                                    $business_name = '';
                                    $comp_bio = '';
                                    $pdf_file = '';
                                    $phone_number = '';
                                    $partner_account = '';
                                    $attributes = '';
                                    $country = '';
                                    $state = '';
                                    $create_n_ship_time = '';
                                    $typical_run_time = '';
                                    $avg_yearly_sales = '';
                                    $notable_projects = '';
                                    $project_gallery = '';
                                ?>
                            <?php endif; ?>



                            <div id="complete_profile">
                                <form action="/influencer/complete-user-profile" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <center>
                                        <img src="<?php echo e($company_logo); ?>" id="logo_pic" alt="Company Logo"
                                            class="user_comp_logo" onclick="clickToChangeLogo(this)">
                                    </center>
                                    <input type="file" class="comp_logo_input d-none" name="user_comp_logo"
                                        accept="image/*" oninput="logo_pic.src=window.URL.createObjectURL(this.files[0])">


                                    <div class="form-group">
                                        <label>Business Name For Your Profile</label>
                                        <input type="text" class="form-control" required value="<?php echo e($business_name); ?>"
                                            name="business_name">
                                    </div>

                                    <div class="form-group">
                                        <label>Company Bio</label>
                                        <textarea class="form-control" id="comp_bio" name="comp_bio" rows="3" required><?php echo e($comp_bio); ?></textarea>
                                    </div>

                                    <div class="form-group">
                                        <label>
                                            Company Catalog PDF
                                            <?php if($pdf_file != ''): ?>
                                                ( <a class="text-primary" href="<?php echo e($pdf_file); ?>" download>See PDF</a> )
                                            <?php endif; ?>
                                        </label>

                                        <input type="file" class="form-control" name="comp_pdf" accept=".doc,.docx,.pdf">
                                    </div>

                                    <div class="form-group">
                                        <label> Contact Phone Number </label>
                                        <input type="text" class="form-control" required value="<?php echo e($phone_number); ?>"
                                            name="phone_number" maxlength="15">
                                    </div>

                                    <div class="text-dark font-weight-bold mt-3">Type of Partner Account</div>
                                    <div class="form-check">
                                        <input class="" type="radio"
                                            <?php if($partner_account == 'option1'): ?> checked <?php endif; ?> name="partnerType"
                                            id="partnerType1" value="option1">
                                        <label class="form-check-label" for="partnerType1">
                                            I am a manufacturer who sells physical products
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="" type="radio" name="partnerType" id="partnerType2"
                                            value="option2" <?php if($partner_account == 'option2'): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="partnerType2">
                                            I am a specialist or service provider
                                        </label>
                                    </div>



                                    <div class="text-dark font-weight-bold my-3">Your Attributes </div>

                                    <div class="row px-3">
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check1"
                                                value="10+ Years in Business" name="attribute[]"
                                                <?php if(strpos($attributes, '10+ Years in Business') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check1">10+ Years in Business</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check2"
                                                value="Packaging Options Available" name="attribute[]"
                                                <?php if(strpos($attributes, 'Packaging Options Available') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check2">Packaging Options
                                                Available</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check3"
                                                value="Private Label Products" name="attribute[]"
                                                <?php if(strpos($attributes, 'Private Label Products') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check3">Private Label Products</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check4" value="Female Owned"
                                                name="attribute[]" <?php if(strpos($attributes, 'Female Owned') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check4">Female Owned</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check5" value="BIPOC Owned"
                                                name="attribute[]" <?php if(strpos($attributes, 'BIPOC Owned') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check5">BIPOC Owned</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check6"
                                                value="Sustainable Materials" name="attribute[]"
                                                <?php if(strpos($attributes, 'Sustainable Materials') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check6">Sustainable Materials</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check7" value="Low MOQs"
                                                name="attribute[]" <?php if(strpos($attributes, 'Low MOQs') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check7">Low MOQs</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check8"
                                                value="Contract Manufacturer" name="attribute[]"
                                                <?php if(strpos($attributes, 'Contract Manufacturer') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check8">Contract Manufacturer</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check9"
                                                value="48 Hour Production Times" name="attribute[]"
                                                <?php if(strpos($attributes, '48 Hour Production Times') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check9">48 Hour Production
                                                Times</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check10"
                                                value="Capacity for 25k+ Units" name="attribute[]"
                                                <?php if(strpos($attributes, 'Capacity for 25k+ Units') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check10">Capacity for 25k+ Units</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check11" value="Vegan"
                                                name="attribute[]" <?php if(strpos($attributes, 'Vegan') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check11">Vegan</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check12"
                                                value="All Natural Ingredients" name="attribute[]"
                                                <?php if(strpos($attributes, 'All Natural Ingredients') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check12">All Natural Ingredients</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check13"
                                                value="Certified Organic" name="attribute[]"
                                                <?php if(strpos($attributes, 'Certified Organic') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check13">Certified Organic</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check14" value="FDA Approved"
                                                name="attribute[]" <?php if(strpos($attributes, 'FDA Approved') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check14">FDA Approved</label>
                                        </div>
                                        <div class=" col-md-4">
                                            <input class="" type="checkbox" id="check15" value="Fine Jewelry"
                                                name="attribute[]" <?php if(strpos($attributes, 'Fine Jewelry') !== false): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="check15">Fine Jewelry</label>
                                        </div>

                                    </div>






                                    <div class="row mt-3">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label> Country/Region</label>
                                                <input type="text" class="form-control" required
                                                    value="<?php echo e($country); ?>" name="country_name">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label> State </label>
                                                <input type="text" class="form-control" required
                                                    value="<?php echo e($state); ?>" name="state">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label> How long does it take to create & ship samples to
                                                    customers after purchase? (In Days) </label>
                                                <input type="number" class="form-control" required
                                                    value="<?php echo e($create_n_ship_time); ?>" name="timeforcreateship">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label> How long does it take to complete a typical
                                                    production run? (In Days) </label>
                                                <input type="number" class="form-control" required
                                                    value="<?php echo e($typical_run_time); ?>" name="prod_full_time">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label> What is your average yearly sales? (In $)
                                                </label>
                                                <input type="number" class="form-control" required
                                                    value="<?php echo e($avg_yearly_sales); ?>" name="avg_yearly_sale">
                                            </div>
                                        </div>

                                    </div>

                                    <div class="form-group">
                                        <label> Notable Past Projects or Clients </label>
                                        <input type="text" class="form-control" required
                                            value="<?php echo e($notable_projects); ?>" name="notable_projects_n_clients">
                                    </div>

                                    <div class="form-group">
                                        <label> Past Projects Gallery </label>
                                        <input type="file" class="form-control" name="past_project_gallery[]"
                                            accept="image/*" multiple onchange="showMultipleImages(this)">
                                    </div>

                                    <div id="multple_gallery">
                                        <?php
                                            if ($project_gallery != '') {
                                                $images = explode('|', $project_gallery);
                                                foreach ($images as $key => $imgsrc) {
                                                    echo '<div class="gallery_line"><img src="' . $imgsrc . '"/></div>';
                                                }
                                            }
                                        ?>
                                    </div>


                                    <center>
                                        <button class="btn btn-dark px-5">Complete Profile</button>
                                    </center>


                                </form>



                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".profile").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('menufacturers.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\vendorSystem\resources\views/influencers/pages/profile_setup.blade.php ENDPATH**/ ?>