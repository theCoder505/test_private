

<?php $__env->startSection('title'); ?>
    Website Information
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <h1 class="text-center pt-5 font-weight-bold mt-5 "> Mange Site Information </h1>

    <?php if(session()->has('alertMsg')): ?>
        <div class="alert font-weight-bold text-center alert-<?php echo e(session()->get('type')); ?> alert-dismissible fade show"
            role="alert">
            <?php echo e(session()->get('alertMsg')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="container">
        <div id="formPart" class="darkBlueBg p-5 m-3">


            <?php $__empty_1 = true; $__currentLoopData = $infodata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siteinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <form action="/admin/edit-site-information" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div id="siteLogo">
                        <img src="<?php echo e(asset($siteinfo->sitelogo)); ?>" alt="" class="sitelogo" id="outPutImage">
                    </div>

                    <div class="form-group">
                        <label>Select Site Logo</label>
                        <input type="file" accept="images/*" class="form-control" name="sitelogo" id="logo"
                            onchange="loadFile(event)">
                    </div>

                    <div id="siteLogo">
                        <img src="<?php echo e(asset($siteinfo->siteicon)); ?>" alt="" class="sitelogo" id="outPutImage2">
                    </div>

                    <div class="form-group">
                        <label>Website Icon</label>
                        <input type="file" accept="images/*" class="form-control" name="siteicon" id="logo2"
                            onchange="loadFile2(event)">
                    </div>


                    <div class="form-group">
                        <label>Website Brand Name </label>
                        <input type="text" class="form-control" required name="websitename"
                            value="<?php echo e($siteinfo->main_sitename); ?>">
                    </div>


                    <div class="form-group">
                        <label>Contact Email Address</label>
                        <input type="email" class="form-control" required name="contactEmail"
                            value="<?php echo e($siteinfo->email); ?>">
                    </div>

                    <div class="form-group">
                        <label>Contact Number</label>
                        <input type="text" class="form-control" required name="contactnmbr"
                            value="<?php echo e($siteinfo->phone); ?>">
                    </div>

                    <div class="form-group">
                        <label>Facebook Page Link</label>
                        <input type="text" class="form-control" required name="fb_link"
                            value="<?php echo e($siteinfo->facebook); ?>">
                    </div>

                    <div class="form-group">
                        <label>Instagram Page Link</label>
                        <input type="text" class="form-control" required name="insta_link"
                            value="<?php echo e($siteinfo->instagram); ?>">
                    </div>

                    <div class="form-group">
                        <label>Twitter Page Link</label>
                        <input type="text" class="form-control" required name="twit_link"
                            value="<?php echo e($siteinfo->tweeter); ?>">
                    </div>

                    <div class="form-group">
                        <label>LinkedIn Page Link</label>
                        <input type="text" class="form-control" required name="linked_link"
                            value="<?php echo e($siteinfo->linkedin); ?>">
                    </div>

                    <div class="form-group">
                        <label>Whatsapp Number</label>
                        <input type="text" class="form-control" required name="wp_nmbr"
                            value="<?php echo e($siteinfo->whatsapp); ?>">
                    </div>

                    <div class="form-group">
                        <label>Youtube Link</label>
                        <input type="text" class="form-control" required name="youtube_link"
                            value="<?php echo e($siteinfo->youtube); ?>">
                    </div>

                    <div class="form-group">
                        <label for="cntctaddr">Contact Address</label>
                        <textarea class="form-control" id="cntctaddr" rows="5" name="contactaddress"><?php echo e($siteinfo->brand_location); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="cntctaddr">Terms & Conditions Page Data</label>
                        <textarea class="form-control" id="tinymce_desc" rows="5" name="terms"><?php echo e($term_data); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="cntctaddr">Privacy & Policies Page Data</label>
                        <textarea class="form-control" id="tinymce_desc_2" rows="5" name="privacy"><?php echo e($privacy_data); ?></textarea>
                    </div>



                    <center>
                        <button type="submit" class="btn btn-lg btn-primary px-5">COMPLETE & UPLOAD</button>
                    </center>

                </form>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
    </div>








    <script>
        $(".siteinfo").addClass("active");


        tinymce.init({
            selector: '#tinymce_desc',
        });

        tinymce.init({
            selector: '#tinymce_desc_2',
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/admin/adminpages/siteinfo.blade.php ENDPATH**/ ?>