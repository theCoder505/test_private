

<?php $__env->startSection('title'); ?>
    Existing Brands - <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <?php $__empty_1 = true; $__currentLoopData = $brand_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <section class="first_section">
            <h1 class="next_gen_capital_text sec_1_title" contenteditable="true"> <?php echo $brand->sec_1_title; ?>

            </h1>

            <p class="getup_text sec_1_short_desac" contenteditable="true">
                <?php echo $brand->sec_1_short_desac; ?>

            </p>




            <div class="container my-5">

                <div class="existing_brands affordable">

                    <div class="existing_line">
                        <div class="row">
                            <div class="col-8">
                                <p class="place_header div_1_title" contenteditable="true"><?php echo $brand->div_1_title; ?></p>
                                <p class="place_details div_1_text" contenteditable="true"><?php echo $brand->div_1_text; ?></p>
                            </div>
                            <div class="center_items col-4">
                                <img src="<?php echo $brand->div_1_img; ?>" alt="photo"
                                    class="place_manage_img div_1_img image_thing">
                            </div>
                        </div>
                    </div>

                    <div class="existing_line">
                        <div class="row">
                            <div class="col-8">
                                <p class="place_header div_2_title" contenteditable="true"><?php echo $brand->div_2_title; ?></p>
                                <p class="place_details div_2_text" contenteditable="true">
                                    <?php echo $brand->div_2_text; ?>

                                </p>
                            </div>
                            <div class="center_items col-4">
                                <img src="<?php echo $brand->div_2_img; ?>" alt="photo"
                                    class="place_manage_img div_2_img image_thing">
                            </div>
                        </div>
                    </div>

                    <div class="existing_line">
                        <div class="row">
                            <div class="col-8">
                                <p class="place_header div_3_title" contenteditable="true"><?php echo $brand->div_3_title; ?></p>
                                <p class="place_details div_3_text" contenteditable="true">
                                    <?php echo $brand->div_3_text; ?>

                                </p>
                            </div>
                            <div class="center_items col-4">
                                <img src="<?php echo $brand->div_3_img; ?>" alt="photo"
                                    class="place_manage_img div_3_img image_thing">
                            </div>
                        </div>
                    </div>

                    <div class="existing_line">
                        <div class="row">
                            <div class="col-8">
                                <p class="place_header div_4_title" contenteditable="true"><?php echo $brand->div_4_title; ?></p>
                                <p class="place_details div_4_text" contenteditable="true">
                                    <?php echo $brand->div_4_text; ?>

                                </p>
                            </div>
                            <div class="center_items col-4">
                                <img src="<?php echo $brand->div_4_img; ?>" alt="photo"
                                    class="place_manage_img div_4_img image_thing">
                            </div>
                        </div>
                    </div>

                    <div class="existing_line">
                        <div class="row">
                            <div class="col-8">
                                <p class="place_header div_5_title" contenteditable="true"><?php echo $brand->div_5_title; ?></p>
                                <p class="place_details div_5_text" contenteditable="true">
                                    <?php echo $brand->div_5_text; ?>

                                </p>
                            </div>
                            <div class="center_items col-4">
                                <img src="<?php echo $brand->div_5_img; ?>" alt="photo"
                                    class="place_manage_img div_5_img image_thing">
                            </div>
                        </div>
                    </div>

                    <div class="existing_line">
                        <div class="row">
                            <div class="col-8">
                                <p class="place_header div_6_title" contenteditable="true"><?php echo $brand->div_6_title; ?></p>
                                <p class="place_details div_6_text" contenteditable="true">
                                    <?php echo $brand->div_6_text; ?>

                                </p>
                            </div>
                            <div class="center_items col-4">
                                <img src="<?php echo $brand->div_6_img; ?>" alt="photo"
                                    class="place_manage_img div_6_img image_thing">
                            </div>
                        </div>
                    </div>

                    <div class="existing_line">
                        <div class="row">
                            <div class="col-8">
                                <p class="place_header div_7_title" contenteditable="true"><?php echo $brand->div_7_title; ?></p>
                                <p class="place_details div_7_text" contenteditable="true">
                                    <?php echo $brand->div_7_text; ?>

                                </p>
                            </div>
                            <div class="center_items col-4">
                                <img src="<?php echo $brand->div_7_img; ?>" alt="photo"
                                    class="place_manage_img div_7_img image_thing">
                            </div>
                        </div>
                    </div>

                    <div class="existing_line">
                        <div class="row">
                            <div class="col-8">
                                <p class="place_header div_8_title" contenteditable="true"><?php echo $brand->div_8_title; ?></p>
                                <p class="place_details div_8_text" contenteditable="true">
                                    <?php echo $brand->div_8_text; ?>

                                </p>
                            </div>
                            <div class="center_items col-4">
                                <img src="<?php echo $brand->div_8_img; ?>" alt="photo"
                                    class="place_manage_img div_8_img image_thing">
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </section>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>

    <?php echo $__env->make('surface.pages.brands_common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        $(".exstngbrands").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/surface/pages/existing-brands.blade.php ENDPATH**/ ?>