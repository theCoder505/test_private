

<?php $__env->startSection('title'); ?>
    Find Suppliers/Menufacturers From <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- // main webpage content is here  -->
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <h2 class="centered_text">Welcome back to <?php echo e($appname); ?> </h2>

                        <div class="portal_line">
                            <h3 class="headline_text">
                                Find Suppliers/Menufacturers From <?php echo e($appname); ?>

                            </h3>

                            <div class="item_grid_4">


                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/training.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Training Module</p>
                                    <p class="item_desc">Learn how to use the Partner Portal to find
                                        customers and...</p>
                                    <center>
                                        <a href="/link" class="continue_btn">Continue Reading</a>
                                    </center>
                                </div>

                            </div>
                        </div>


                    </div>
                </div>

                <div id="styleSelector">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".home").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('menufacturers.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\vendorSystem\resources\views/influencers/pages/dashboard.blade.php ENDPATH**/ ?>