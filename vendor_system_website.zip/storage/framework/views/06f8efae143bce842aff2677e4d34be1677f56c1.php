

<?php $__env->startSection('title'); ?>
    <?php echo e($type); ?> - <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <style>
        p {
            padding-bottom: 0px;
            margin-bottom: 0px;
        }
    </style>
    <div class="container">
        <div class="terms_title"><?php echo e($type); ?></div>

        <pre class="blog_main_details mb-5 pb-5"><?php echo $data; ?></pre>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".home").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/surface/pages/more_page.blade.php ENDPATH**/ ?>