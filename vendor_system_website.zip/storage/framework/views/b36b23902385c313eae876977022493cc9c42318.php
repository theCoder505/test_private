

<?php $__env->startSection('title'); ?>
    Find Suppliers/Menufacturers From <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- // main webpage content is here  -->
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <h2 class="centered_text">Welcome back to <?php echo e($appname); ?> </h2>

                        <div class="portal_line">
                            <h3 class="headline_text">
                                Find Suppliers/Menufacturers From <?php echo e($appname); ?>

                            </h3>

                            <div class="item_grid_4">


                                <?php $__empty_1 = true; $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="item_grid_line">
                                        <div class="prod_item_img_holder">
                                            <?php
                                                $images = explode('|', $item->project_photos);
                                                foreach ($images as $key => $imgsrc) {
                                                    if ($key < 1) {
                                                        echo '<img src="' . $imgsrc . '" alt="" class="item_img">';
                                                    }
                                                }
                                            ?>

                                        </div>
                                        <p class="prod_item_title"><?php echo e($item->item_name); ?></p>
                                        <p class="item_category">Category: <?php echo e($item->product_category); ?></p>
                                        <center>
                                            <a href="/see-product/<?php echo e($item->sno); ?>/<?php echo e($item->product_category); ?>/<?php echo e($item->item_name); ?>"
                                                class="continue_btn">See Product</a>
                                        </center>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>

                            </div>
                        </div>


                    </div>
                </div>

                <div id="styleSelector">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".home").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('influencers.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/influencers/pages/dashboard.blade.php ENDPATH**/ ?>