

<?php $__env->startSection('title'); ?>
    Your All Ordered Products | <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .portal_line {
            width: 100%;
            overflow-x: auto;
        }
    </style>

    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <div class="col-12 allAlerts">
                            <?php if(session()->has('alertMsg')): ?>
                                <div class="alert text-center <?php echo e(session()->get('type')); ?> alert-dismissible fade show"
                                    role="alert">
                                    <?php echo e(session()->get('alertMsg')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>


                        <div class="rfp_holder">
                            <h2 class="centered_text"> Create New RFP </h2>

                            <div class="portal_line">


                                <?php $__empty_1 = true; $__currentLoopData = $particular_rfp_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <form action="/entrepreneur/edit-particular-rfp-post" method="post"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>

                                        <input type="hidden" name="edit_rfp_sno" value="<?php echo e($rfp_serial); ?>">
                                        <input type="hidden" name="edit_rfp_category" value="<?php echo e($rfp_category); ?>">
                                        <input type="hidden" name="edit_rfp_title" value="<?php echo e($rfp_title); ?>">



                                        <div class="form-group">
                                            <label>RFP For User Type:</label>
                                            <select name="rfp_for" class="form-control" required>
                                                <option <?php if($item->rfp_for == 'influencer'): ?> selected <?php endif; ?>
                                                    value="influencer">
                                                    Influencer
                                                </option>
                                                <option <?php if($item->rfp_for == 'menufacturer'): ?> selected <?php endif; ?>
                                                    value="menufacturer">
                                                    Menufacturer
                                                </option>
                                            </select>
                                        </div>



                                        <div class="form-group">
                                            <label>Product Category For Request</label>
                                            <select name="prod_cat" class="form-control" required>
                                                <option <?php if($item->category == 'Apparel'): ?> selected <?php endif; ?> value="Apparel">
                                                    Apparel</option>
                                                <option <?php if($item->category == 'Babby And Toddler'): ?> selected <?php endif; ?>
                                                    value="Babby And Toddler">Babby And Toddler</option>
                                                <option <?php if($item->category == 'Beauty'): ?> selected <?php endif; ?> value="Beauty">
                                                    Beauty</option>
                                                <option <?php if($item->category == 'Beverage'): ?> selected <?php endif; ?> value="Beverage">
                                                    Beverage</option>
                                                <option <?php if($item->category == 'Candles'): ?> selected <?php endif; ?> value="Candles">
                                                    Candles</option>
                                                <option <?php if($item->category == 'Cleaning Supplies'): ?> selected <?php endif; ?>
                                                    value="Cleaning Supplies">Cleaning Supplies</option>
                                                <option <?php if($item->category == 'Coffie & Tea'): ?> selected <?php endif; ?>
                                                    value="Coffie & Tea">Coffie & Tea</option>
                                                <option <?php if($item->category == 'Condiments'): ?> selected <?php endif; ?>
                                                    value="Condiments">Condiments</option>
                                                <option <?php if($item->category == 'Fashion Accessories'): ?> selected <?php endif; ?>
                                                    value="Fashion Accessories">Fashion Accessories</option>
                                                <option <?php if($item->category == 'Fitness'): ?> selected <?php endif; ?> value="Fitness">
                                                    Fitness</option>
                                                <option <?php if($item->category == 'Foods'): ?> selected <?php endif; ?> value="Foods">
                                                    Foods</option>
                                                <option <?php if($item->category == 'Fragnance'): ?> selected <?php endif; ?>
                                                    value="Fragnance">Fragnance</option>
                                                <option <?php if($item->category == 'Home Goods'): ?> selected <?php endif; ?>
                                                    value="Home Goods">Home Goods</option>
                                                <option <?php if($item->category == 'Jewellery'): ?> selected <?php endif; ?>
                                                    value="Jewellery">Jewellery</option>
                                                <option <?php if($item->category == 'Leather Goods'): ?> selected <?php endif; ?>
                                                    value="Leather Goods">Leather Goods</option>
                                                <option <?php if($item->category == 'Merch'): ?> selected <?php endif; ?> value="Merch">
                                                    Merch</option>
                                                <option <?php if($item->category == 'Pet'): ?> selected <?php endif; ?> value="Pet">
                                                    Pet</option>
                                                <option <?php if($item->category == 'Paper Goods'): ?> selected <?php endif; ?>
                                                    value="Paper Goods">Paper Goods</option>
                                                <option <?php if($item->category == 'Shoes'): ?> selected <?php endif; ?> value="Shoes">
                                                    Shoes</option>
                                                <option <?php if($item->category == 'Smooking Accessories'): ?> selected <?php endif; ?>
                                                    value="Smooking Accessories">Smooking Accessories</option>
                                                <option <?php if($item->category == 'Sweets'): ?> selected <?php endif; ?> value="Sweets">
                                                    Sweets</option>
                                                <option <?php if($item->category == 'Swimwears'): ?> selected <?php endif; ?>
                                                    value="Swimwears">Swimwears</option>
                                                <option <?php if($item->category == 'Tech Gadgeets'): ?> selected <?php endif; ?>
                                                    value="Tech Gadgeets">Tech Gadgeets</option>
                                                <option <?php if($item->category == 'Toys'): ?> selected <?php endif; ?> value="Toys">
                                                    Toys</option>
                                                <option <?php if($item->category == 'Toys & Games'): ?> selected <?php endif; ?>
                                                    value="Toys & Games">Toys & Games</option>
                                                <option <?php if($item->category == 'Wellness'): ?> selected <?php endif; ?>
                                                    value="Wellness">Wellness</option>
                                            </select>
                                        </div>


                                        <div class="form-group">
                                            <label>Product Title</label>
                                            <input type="text" class="form-control" name="product_title"
                                                value="<?php echo e($item->title); ?>" required>
                                        </div>


                                        <div class="form-group">
                                            <label> Please upload reference photos and/or design files for your supplier:
                                            </label>
                                            <input type="file" class="form-control" name="product_image[]"
                                                accept="image/*" multiple onchange="showMultipleImages(this)">
                                        </div>

                                        <div id="multple_gallery">
                                            <?php
                                                $images = explode('|', $item->rfp_images);
                                                foreach ($images as $key => $imgsrc) {
                                                    echo '<div class="gallery_line"><img src="' . $imgsrc . '"/></div>';
                                                }
                                            ?>
                                        </div>


                                        <div class="form-group">
                                            <label>Describe your project in detail:</label>
                                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="5" required name="prod_details"><?php echo e($item->description); ?></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label>Please add any reference links to help suppliers understand what you’re
                                                looking
                                                for:</label>
                                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" required name="ref_links"><?php echo e($item->ref_links); ?></textarea>
                                        </div>



                                        <div class="form-group">
                                            <label>Do you need a custom sample before ordering bulk?</label>
                                            <select name="need_smaple_query" class="form-control" required>
                                                <option <?php if($item->sample_query == 'Yes'): ?> selected <?php endif; ?> value="Yes">
                                                    Yes</option>
                                                <option <?php if($item->sample_query == 'No'): ?> selected <?php endif; ?> value="No">
                                                    No</option>
                                            </select>
                                        </div>


                                        <div class="form-group">
                                            <label>How many units would you like to produce?</label>
                                            <select name="units_to_produce" class="form-control" required>
                                                <option <?php if($item->units == '50-250'): ?> selected <?php endif; ?> value="50-250">
                                                    50-250</option>
                                                <option <?php if($item->units == '250-500'): ?> selected <?php endif; ?> value="250-500">
                                                    250-500</option>
                                                <option <?php if($item->units == '500-1000'): ?> selected <?php endif; ?>
                                                    value="500-1000">500-1000</option>
                                                <option <?php if($item->units == '1000+'): ?> selected <?php endif; ?> value="1000+">
                                                    1000+</option>
                                            </select>
                                        </div>


                                        <div class="form-group">
                                            <label>When do you want to launch this product?</label>
                                            <select name="launch_time" class="form-control" required>
                                                <option <?php if($item->launch_time == '1 - 3 months'): ?> selected <?php endif; ?>
                                                    value="1 - 3 months">1 - 3 months</option>
                                                <option <?php if($item->launch_time == '3 -6 months'): ?> selected <?php endif; ?>
                                                    value="3 -6 months">3 -6 months</option>
                                                <option <?php if($item->launch_time == '6 - 12 months'): ?> selected <?php endif; ?>
                                                    value="6 - 12 months">6 - 12 months</option>
                                                <option <?php if($item->launch_time == '12+ months'): ?> selected <?php endif; ?>
                                                    value="12+ months">12+ months</option>
                                            </select>
                                        </div>


                                        <div class="form-group">
                                            <label>What is your budget?</label>
                                            <select name="budget" class="form-control" required>
                                                <option <?php if($item->budget == '<$500'): ?> selected <?php endif; ?> value="<$500">
                                                    <$500 </option>
                                                <option <?php if($item->budget == '$500 - 1,000'): ?> selected <?php endif; ?>
                                                    value="$500 - 1,000">$500 - 1,000</option>
                                                <option <?php if($item->budget == '$1,000 - 5,000'): ?> selected <?php endif; ?>
                                                    value="$1,000 - 5,000">$1,000 - 5,000</option>
                                                <option <?php if($item->budget == '$5,000 - 10,000'): ?> selected <?php endif; ?>
                                                    value="$5,000 - 10,000">$5,000 - 10,000</option>
                                                <option <?php if($item->budget == '$10,000 - 20,000'): ?> selected <?php endif; ?>
                                                    value="$10,000 - 20,000">$10,000 - 20,000</option>
                                                <option <?php if($item->budget == '$20,000+'): ?> selected <?php endif; ?>
                                                    value="$20,000+">$20,000+</option>
                                            </select>
                                        </div>


                                        <div class="form-group">
                                            <label>Factory Requirements:</label>
                                            <select name="factory_requirements" class="form-control" required>
                                                <option <?php if($item->requirement == 'Made in America Only'): ?> selected <?php endif; ?>
                                                    value="Made in America Only">Made in America Only</option>
                                                <option <?php if($item->requirement == 'Any factory that meets my requirements'): ?> selected <?php endif; ?>
                                                    value="Any factory that meets my requirements">
                                                    Any factory that meets my requirements
                                                </option>
                                            </select>
                                        </div>


                                        <button class="btn btn-dark px-5">Update RFP</button>
                                        <a href="/entrepreneur/see-rfp-responses/<?php echo e($rfp_serial); ?>/<?php echo e($rfp_category); ?>/<?php echo e($rfp_title); ?>"
                                            class="btn btn-info ml-3 px-5">See Responses</a>



                                    </form>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>

                            </div>
                        </div>









                    </div>


                </div>





            </div>


        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".add_rfp").addClass("active");
        let table = new DataTable('#order_table');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('entrepreneurs.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/entrepreneurs/pages/edit_rfp_data.blade.php ENDPATH**/ ?>