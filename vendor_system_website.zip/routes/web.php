<?php

use App\Http\Controllers\admin\adminCredentialsController;
use App\Http\Controllers\admin\AdminRedirects;
use App\Http\Controllers\admin\allBasicWorksController;
use App\Http\Controllers\admin\blogsController;
use App\Http\Controllers\admin\homepageSetupController;
use App\Http\Controllers\admin\siteinfoController;
use App\Http\Controllers\allUsersLoginLogoutController;
use App\Http\Controllers\BrandPagesController;
use App\Http\Controllers\influencer\productController as InfluencerProductController;
use App\Http\Controllers\influencer\vendors_productController;
use App\Http\Controllers\menufacturer\allBasicPagesController;
use App\Http\Controllers\menufacturer\productController;
use App\Http\Controllers\menufacturer\profilesetupController;
use App\Http\Controllers\menufacturer\rfpSetupController;
use App\Http\Controllers\surface\AllPagesController;
use Illuminate\Support\Facades\Route;




// main website routers 
Route::get('/', [AllPagesController::class, 'showHomePage']);

Route::get('/read-blogs', [AllPagesController::class, 'readBlogsPage']);

Route::get('/see-blog/{serial}/{category}/{title}', [AllPagesController::class, 'readParticularBlog']);

Route::get('/see-profile/{user_uid}', [AllPagesController::class, 'redirect_to_spec_user']);

Route::get('/existing-brands', [AllPagesController::class, 'esictingBrnadsPage']);

Route::get('/new-brands', [AllPagesController::class, 'newBrandsPage']);

Route::get('/more-pages/{pagetype}', [AllPagesController::class, 'showSpecPageData']);













// sign in and up to all type usres 
Route::get('/sign-up', [allUsersLoginLogoutController::class, 'showLoginSignUpPage']);

Route::get('/sign-in', [allUsersLoginLogoutController::class, 'showLoginSignUpPage']);

Route::post('/add-new-user-with-otp', [allUsersLoginLogoutController::class, 'addNewUserToDB']);

Route::post('/check-user-otp-and-add-user', [allUsersLoginLogoutController::class, 'checkOtpAddUser']);

Route::post('/send-otp-to-forget-pwd', [allUsersLoginLogoutController::class, 'sendOtpToCheckPwd']);

Route::post('/check-forget-pwd-otp', [allUsersLoginLogoutController::class, 'crossCheckForgetOtp']);

Route::post('/sign-in-existing-user', [allUsersLoginLogoutController::class, 'signInExistingUser']);

Route::get('/logout', [allUsersLoginLogoutController::class, 'logoutExistingUser']);


















// all menufacturers profile and pages 
Route::get('/menufacturer/dashboard', [allBasicPagesController::class, 'sowDashboard']);

Route::get('/menufacturer/Educational-Resources', [allBasicPagesController::class, 'educationalPage']);

Route::get('/influencer/Educational-Resources', [allBasicPagesController::class, 'educationalPageForInluencer']);

Route::get('/menufacturer/Orders-&-Shipments', [allBasicPagesController::class, 'ordersAndShipmentsForMenufacturer']);

Route::post('/menufacturer/change-order-status', [vendors_productController::class, 'updateStatus']);

Route::get('/menufacturer/Set-Up-Profile', [profilesetupController::class, 'setUpProfile']);

Route::post('/menufacturer/complete-user-profile', [profilesetupController::class, 'setupVendorProfile']);

Route::get('/menufacturer/Set-Up-Products', [productController::class, 'setUpProduct']);

Route::post('/menufacturer/add-new-project', [productController::class, 'addNewProduct']);

Route::get('/menufacturer/edit-product/{productid}', [productController::class, 'showEditingPage']);

Route::post('/menufacturer/edit-existing-product', [productController::class, 'editExistingProduct']);

Route::get('/menufacturer/make-custom-request', [productController::class, 'makeCustomRequest']);

Route::post('/menufacturer/new-custom-project-add', [productController::class, 'addNewCustomRequest']);

Route::get('/menufacturer/show-all-rfps', [rfpSetupController::class, 'showAllRfpDatatomenufacturer']);

Route::get('/see-particular-request-for-proposal/{proposal_sno}/{category}/{title}', [rfpSetupController::class, 'particularRequest']);

Route::post('/add-response-on-rfp', [rfpSetupController::class, 'addNewBid']);











Route::get('/{usertype}/Messages', [allBasicPagesController::class, 'sendToPersonalWp']);
Route::get('/contact/menufacturer/{username}/{user_id}', [allBasicPagesController::class, 'sendtoWhatsApp']);













// all influencers profile and pages 
Route::get('/influencer/dashboard', [allBasicPagesController::class, 'showInfluencerDashboard']);

Route::get('/influencer/Orders-&-Shipments', [allBasicPagesController::class, 'ordersAndShipments']);

Route::post('/influencer/change-order-status', [vendors_productController::class, 'updateInfluencerOrderStatus']);

Route::get('/influencer/Set-Up-Profile', [profilesetupController::class, 'setUpInfluencerProfile']);

Route::get('/influencer/Set-Up-Products', [productController::class, 'setUpInfluencerProduct']);

Route::get('/influencer/edit-product/{productid}', [productController::class, 'showInfluencerEditingPage']);

Route::get('/influencer/make-custom-request', [productController::class, 'makeCustomInfluencerRequest']);

Route::post('/influencer/new-custom-project-add', [productController::class, 'addNewInfluencerCustomRequest']);

Route::get('/influencer/edit-custom-request-product/{productid}', [productController::class, 'editCustomInfluencerProductPage']);

Route::post('/influencer/edit-existing-custom-requested-product', [productController::class, 'editExistingCustomRequestProduct']);

Route::post('/influencer/add-new-project', [productController::class, 'addNewProduct']);

Route::post('/influencer/complete-user-profile', [profilesetupController::class, 'setupVendorProfile']);

Route::post('/influencer/edit-existing-product', [productController::class, 'editExistingProduct']);

Route::get('/influencer/Add-New-RFP', [rfpSetupController::class, 'addNewRFP']);

Route::get('/influencer/see-entrepreneur-RFP', [rfpSetupController::class, 'showentrepreneursRFP']);


Route::post('/influencer/create-new-rfp-post', [rfpSetupController::class, 'postNewInfluencerRFP']);

Route::get('/view-or-edit-rpf/{rfp_serial}/{rfp_category}/{rfp_title}', [rfpSetupController::class, 'showParticularRfpData']);

Route::get('/delete-rpf/{rfp_serial}/{rfp_category}/{rfp_title}', [rfpSetupController::class, 'deleteRFP']);

Route::post('/influencer/edit-particular-rfp-post', [rfpSetupController::class, 'updateExistingInfluencer']);

Route::get('/influencer/see-rfp-responses/{rfp_serial}/{rfp_category}/{rfp_title}', [rfpSetupController::class, 'seeResponses']);

Route::get('/get-order-review/{order_id}', [allBasicPagesController::class, 'getReviewData']); // no middleware

Route::get('/influencer/see-particular-request-for-proposal/{proposal_sno}/{category}/{title}', [rfpSetupController::class, 'particularRequestForInfluencer']);

Route::post('/influencer/add-response-on-rfp', [rfpSetupController::class, 'addNewinfluencerBid']);












// Show products to influencers 
Route::get('/see-product/{prod_serial}/{prod_cat}/{prod_name}', [vendors_productController::class, 'showParticularProduct']);

Route::get('/see-custom-product/{prod_serial}/{prod_cat}/{prod_name}', [vendors_productController::class, 'showCustomProduct']);

Route::post('/send-to-order-product', [vendors_productController::class, 'orderProduct']);

Route::post('/send-to-order-custom-request-product', [vendors_productController::class, 'customOrderProduct']);

Route::post('/accept-order-request', [vendors_productController::class, 'acceptOrderRequest']);

Route::get('/see-vendor-profile/{vendortype}/{vendoruid}', [vendors_productController::class, 'showVendorProfile']);

Route::get('/review-order/{order_serial}/{prod_serial}/{prod_cat}/{prod_name}', [vendors_productController::class, 'reviewPArticularOrder']);

Route::post('/review-the-product', [vendors_productController::class, 'addNewReview']);






















// all entrepreneurs profiles pages and everything | entrepreneur
Route::get('/entrepreneur/dashboard', [allBasicPagesController::class, 'showentrepreneurDashboard']);

Route::get('/entrepreneur/Set-Up-Profile', [profilesetupController::class, 'setUpentrepreneurProfile']);

Route::post('/entrepreneur/complete-user-profile', [profilesetupController::class, 'setupVendorProfile']);

Route::get('/entrepreneur/Add-New-RFP', [rfpSetupController::class, 'addNewentrepreneurRFP']);

Route::post('/entrepreneur/create-new-rfp-post', [rfpSetupController::class, 'postNewentrepreneurRFP']);

Route::get('/entrepreneur/view-or-edit-rpf/{rfp_serial}/{rfp_category}/{rfp_title}', [rfpSetupController::class, 'showParticularRfpDataToEnterprenuer']);

Route::get('/entrepreneur/delete-rpf/{rfp_serial}/{rfp_category}/{rfp_title}', [rfpSetupController::class, 'deleteRFP']);

Route::post('/entrepreneur/edit-particular-rfp-post', [rfpSetupController::class, 'updateExistingentrepreneurRFP']);

Route::get('/entrepreneur/see-rfp-responses/{rfp_serial}/{rfp_category}/{rfp_title}', [rfpSetupController::class, 'seeResponsesToentrepreneur']);

Route::get('/entrepreneur/Educational-Resources', [allBasicPagesController::class, 'educationalPageForEntrepreneur']);

Route::get('/entrepreneur/Orders-&-Shipments', [allBasicPagesController::class, 'entrepreneurOrdersAndShipments']);




// Show products to entrepreneurs 
Route::get('/entrepreneur/see-product/{prod_serial}/{prod_cat}/{prod_name}', [vendors_productController::class, 'showParticularProductEnterprenuer']);

Route::get('/for-entrepreneur/see-custom-product/{prod_serial}/{prod_cat}/{prod_name}', [vendors_productController::class, 'showCustomProductForentrepreneur']);

Route::post('/entrepreneur/send-to-order-product', [vendors_productController::class, 'orderProductForentrepreneur']);

Route::post('/entrepreneur/send-custom-request-product-to-order', [vendors_productController::class, 'customOrderProductForentrepreneur']);

Route::get('/entrepreneur/see-vendor-profile/{vendortype}/{vendoruid}', [vendors_productController::class, 'showVendorProfile']);

Route::get('/entrepreneur/review-order/{order_serial}/{prod_serial}/{prod_cat}/{prod_name}', [vendors_productController::class, 'reviewParticularOrderForEnterprenuer']);

Route::post('/entrepreneur/review-the-product', [vendors_productController::class, 'addNewEnterprenuerReview']);

















































// all admin routes 
// admin basic login regestration ->middleware('adminlogincheck')
Route::get('/admin/login', [adminCredentialsController::class, 'showLoginPage']);

Route::get('/admin/forget-password', [adminCredentialsController::class, 'showForgetPwdPage']);

Route::get('/admin/logout', [adminCredentialsController::class, 'logoutAdmin']);

Route::get('/admin/change-admin-email', [AdminRedirects::class, 'mailChangeManagement']);

Route::get('/admin/change-admin-password', [AdminRedirects::class, 'passChangeManagement']);


// admin login credentials all for ******************* ADMIN *******************
Route::post('/check-admin-credential', [adminCredentialsController::class, 'checkCredentials']);

Route::post('/check-forgetting-mail', [adminCredentialsController::class, 'checkMail']);

Route::post('/check-admin-otp', [adminCredentialsController::class, 'checkOTP']);

Route::post('/set-new-password', [adminCredentialsController::class, 'setNewPwd']);


Route::post('/check-admin-old-mail-pass', [adminCredentialsController::class, 'checkOldMailPass']);

Route::post('/set-new-admin-mail', [adminCredentialsController::class, 'setNewAdminMail']);



// admin pages 
Route::get('/admin/admindashboard', [AdminRedirects::class, 'showDashBoard'])->middleware('admincheck');

Route::get('/admin/manage-categories', [allBasicWorksController::class, 'setCategoriesPage'])->middleware('admincheck');

Route::post('/admin/add-new-category', [allBasicWorksController::class, 'addNewcategory'])->middleware('admincheck');

Route::post('/admin/update-category', [allBasicWorksController::class, 'updatecategory'])->middleware('admincheck');

Route::get('/admin/delete-category/{category_sno}', [allBasicWorksController::class, 'deletecategory'])->middleware('admincheck');



Route::get('/admin/manage-resources', [allBasicWorksController::class, 'resourceManagementPage'])->middleware('admincheck');

Route::post('/admin/update-resources', [allBasicWorksController::class, 'resourceManagementUpdate'])->middleware('admincheck');

Route::post('/admin/add-new-menufacturers-resource', [allBasicWorksController::class, 'addNewMenufacturerVidLsns'])->middleware('admincheck');

Route::post('/admin/update-menufacturers-resource', [allBasicWorksController::class, 'updateMenufacturerVidLsns'])->middleware('admincheck');


Route::post('/admin/add-new-influencers-resource', [allBasicWorksController::class, 'addNewinfluencersVidLsns'])->middleware('admincheck');

Route::post('/admin/update-influencers-resource', [allBasicWorksController::class, 'updateinfluencersVidLsns'])->middleware('admincheck');


Route::post('/admin/add-new-entrepreneurs-resource', [allBasicWorksController::class, 'addNewentrepreneursVidLsns'])->middleware('admincheck');

Route::post('/admin/update-entrepreneurs-resource', [allBasicWorksController::class, 'updateentrepreneursVidLsns'])->middleware('admincheck');

Route::get('/admin/delete-resource/{video_lesson_sno}', [allBasicWorksController::class, 'deleteVideoLesson'])->middleware('admincheck');

Route::get('/admin/show-blogs-page', [blogsController::class, 'showBlogPage'])->middleware('admincheck');

Route::post('/admin/add-new-blog', [blogsController::class, 'addNewBlogItem'])->middleware('admincheck');

Route::get('admin/update-blogs/{blog_serial}', [blogsController::class, 'showParticularBlog'])->middleware('admincheck');

Route::post('/admin/update-particular-blog', [blogsController::class, 'updateExistingBlogItem'])->middleware('admincheck');

Route::get('/admin/delete-particular-blog/{blog_serial}', [blogsController::class, 'deleteExistingBlogItem'])->middleware('admincheck');



Route::get('/admin/manage-faqs', [AdminRedirects::class, 'manageFaqs'])->middleware('admincheck');

Route::post('/admin/add-new-faq', [AdminRedirects::class, 'addNewFaq'])->middleware('admincheck');

Route::post('/admin/update-faq', [AdminRedirects::class, 'updateFaq'])->middleware('admincheck');

Route::get('/admin/delete-faq/{faq_sno}', [AdminRedirects::class, 'deletefaq'])->middleware('admincheck');



// setup site infos
Route::get('/admin/site-information-setup', [siteinfoController::class, 'showPage'])->middleware('admincheck');

Route::post('/admin/edit-site-information', [siteinfoController::class, 'editInformation'])->middleware('admincheck');

Route::get('/admin/homepage-edit', [homepageSetupController::class, 'showHomePageInformation'])->middleware('admincheck');

Route::post('/admin/update-homepage', [homepageSetupController::class, 'updateHomePageInformation'])->middleware('admincheck');

Route::get('/admin/edit-brand-pages', [BrandPagesController::class, 'showBrandPageInformation'])->middleware('admincheck');

Route::post('/admin/update-brand-pages-data', [BrandPagesController::class, 'updateBrandPageInformation'])->middleware('admincheck');

















