

<?php $__env->startSection('title'); ?>
    Add New Post & See All Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">


                <div class="col-12 allAlerts">
                    <?php if(session()->has('alertMsg')): ?>
                        <div class="alert text-center <?php echo e(session()->get('type')); ?> alert-dismissible fade show"
                            role="alert">
                            <?php echo e(session()->get('alertMsg')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>





                <div class="showAddNewPost mb-5">

                    <div class="add_posts_form">

                        <div class="row">
                            <div class="col">
                                <h2 class="mb-2 mb-md-4 text-center title">
                                    Resource Management For Menufacturers
                                </h2>
                            </div>
                        </div>



                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <form action="/admin/update-resources" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="">
                                        Training Module
                                        <a target="_blank" href="<?php echo e($data->traning_module); ?>" class="mb-2">(See Current
                                            One)</a>
                                    </label>
                                    <input type="file" name="traning_module" id="" class="form-control"
                                        accept="doc,.docx,.pdf">
                                </div>

                                <div class="form-group">
                                    <label for="">
                                        Invoicing & Fulfillment
                                        <a target="_blank" href="<?php echo e($data->invoicing_fullfilment); ?>" class="mb-2">(See
                                            Current One)</a>
                                    </label>
                                    <input type="file" name="invoicing_fullfilment" id="" class="form-control"
                                        accept="doc,.docx,.pdf">
                                </div>

                                <div class="form-group">
                                    <label for="">
                                        Receiving Guidelines
                                        <a target="_blank" href="<?php echo e($data->receiving_guidelines); ?>" class="mb-2">(See
                                            Current One)</a>
                                    </label>
                                    <input type="file" name="receiving_guidelines" id="" class="form-control"
                                        accept="doc,.docx,.pdf">
                                </div>

                                <div class="form-group">
                                    <label for="">
                                        Set Up Business Profile
                                        <a target="_blank" href="<?php echo e($data->setup_business_profile); ?>" class="mb-2">(See
                                            Current One)</a>
                                    </label>
                                    <input type="file" name="setup_business_profile" id="" class="form-control"
                                        accept="doc,.docx,.pdf">
                                </div>

                                <div class="form-group">
                                    <label for="">
                                        Orders & Shipments
                                        <a target="_blank" href="<?php echo e($data->orders_shipments); ?>" class="mb-2">(See Current
                                            One)</a>
                                    </label>
                                    <input type="file" name="orders_shipments" id="" class="form-control"
                                        accept="doc,.docx,.pdf">
                                </div>

                                <center>
                                    <button class="btn btn-primary px-5">UPDATE</button>
                                </center>

                            </form>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>


                    </div>
                </div>





                <div class="showAddNewPost mb-5">
                    <div class="add_posts_form">

                        <div class="row">
                            <div class="col">
                                <h2 class="mb-2 mb-md-4 text-center title">
                                    Educational Resources For Menufacturers
                                </h2>
                            </div>
                        </div>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Iframe/Embedded Code</th>
                                    <th scope="col">Update</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <form action="/admin/add-new-menufacturers-resource" method="post">
                                        <?php echo csrf_field(); ?>
                                        <th scope="row"> 0 </th>
                                        <td>
                                            <textarea class="form-control" required name="embedded_code" rows="3" placeholder="Embedded/Iframe Code"></textarea>
                                        </td>
                                        <td>
                                            <button class="btn btn-primary btn-sm px-5">Add New</button>
                                        </td>
                                        <td></td>
                                    </form>
                                </tr>
                                <?php $__empty_1 = true; $__currentLoopData = $all_menufacturers_lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <form action="/admin/update-menufacturers-resource" method="post">
                                            <?php echo csrf_field(); ?>
                                            <th scope="row"><?php echo e($key + 1); ?> </th>
                                            <td>
                                                <input type="hidden" name="serial" value="<?php echo e($item->sno); ?>">
                                                <textarea class="form-control" required name="embedded_code" rows="3" placeholder="Embedded/Iframe Code"><?php echo e($item->resource_code); ?></textarea>
                                            </td>
                                            <td>
                                                <button class="btn btn-primary btn-sm px-5">Update</button>
                                            </td>
                                            <td>
                                                <a href="/admin/delete-resource/<?php echo e($item->sno); ?>"
                                                    class="btn btn-danger btn-sm px-5">Delete</a>
                                            </td>
                                        </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </tbody>
                        </table>

                    </div>
                </div>






                <div class="showAddNewPost mb-5">
                    <div class="add_posts_form">

                        <div class="row">
                            <div class="col">
                                <h2 class="mb-2 mb-md-4 text-center title">
                                    Educational Resources For Influencers
                                </h2>
                            </div>
                        </div>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Iframe/Embedded Code</th>
                                    <th scope="col">Update</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <form action="/admin/add-new-influencers-resource" method="post">
                                        <?php echo csrf_field(); ?>
                                        <th scope="row"> 0 </th>
                                        <td>
                                            <textarea class="form-control" required name="embedded_code" rows="3" placeholder="Embedded/Iframe Code"></textarea>
                                        </td>
                                        <td>
                                            <button class="btn btn-primary btn-sm px-5">Add New</button>
                                        </td>
                                        <td></td>
                                    </form>
                                </tr>
                                <?php $__empty_1 = true; $__currentLoopData = $all_influencers_lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <form action="/admin/update-influencers-resource" method="post">
                                            <?php echo csrf_field(); ?>
                                            <th scope="row"><?php echo e($key + 1); ?> </th>
                                            <td>
                                                <input type="hidden" name="serial" value="<?php echo e($item->sno); ?>">
                                                <textarea class="form-control" required name="embedded_code" rows="3" placeholder="Embedded/Iframe Code"><?php echo e($item->resource_code); ?></textarea>
                                            </td>
                                            <td>
                                                <button class="btn btn-primary btn-sm px-5">Update</button>
                                            </td>
                                            <td>
                                                <a href="/admin/delete-resource/<?php echo e($item->sno); ?>"
                                                    class="btn btn-danger btn-sm px-5">Delete</a>
                                            </td>
                                        </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </tbody>
                        </table>

                    </div>
                </div>







                <div class="showAddNewPost mb-5">
                    <div class="add_posts_form">

                        <div class="row">
                            <div class="col">
                                <h2 class="mb-2 mb-md-4 text-center title">
                                    Educational Resources For Entrepreneurs
                                </h2>
                            </div>
                        </div>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Iframe/Embedded Code</th>
                                    <th scope="col">Update</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <form action="/admin/add-new-entrepreneurs-resource" method="post">
                                        <?php echo csrf_field(); ?>
                                        <th scope="row"> 0 </th>
                                        <td>
                                            <textarea class="form-control" required name="embedded_code" rows="3" placeholder="Embedded/Iframe Code"></textarea>
                                        </td>
                                        <td>
                                            <button class="btn btn-primary btn-sm px-5">Add New</button>
                                        </td>
                                        <td></td>
                                    </form>
                                </tr>
                                <?php $__empty_1 = true; $__currentLoopData = $all_entreprenuers_lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <form action="/admin/update-entrepreneurs-resource" method="post">
                                            <?php echo csrf_field(); ?>
                                            <th scope="row"><?php echo e($key + 1); ?> </th>
                                            <td>
                                                <input type="hidden" name="serial" value="<?php echo e($item->sno); ?>">
                                                <textarea class="form-control" required name="embedded_code" rows="3" placeholder="Embedded/Iframe Code"><?php echo e($item->resource_code); ?></textarea>
                                            </td>
                                            <td>
                                                <button class="btn btn-primary btn-sm px-5">Update</button>
                                            </td>
                                            <td>
                                                <a href="/admin/delete-resource/<?php echo e($item->sno); ?>"
                                                    class="btn btn-danger btn-sm px-5">Delete</a>
                                            </td>
                                        </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </tbody>
                        </table>

                    </div>
                </div>



            </div>
        </div>
    </div>


    <script>
        $(".manageresources").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/admin/adminpages/resource_management_page.blade.php ENDPATH**/ ?>