<center>
    <h1>Email for Admin for forget / reset password from "<i> <?php echo e($appname); ?> </i>" </h1>
</center>
<hr>
<hr>


<p>
    Dear Admin, as you requested a forget / reset password option in your website - <?php echo e($appname); ?>. <br>
    We are providing you a 6 digit OTP. Use this OTP and continue... <br>

<p>The OTP is : <b><?php echo e($theOtp); ?></b></p>
<br>
<br>
<i> If you did not tried to open the account, no further action is required. </i>

<br>
</p>

<hr>
<hr>

<h3>
    <b>
        Best Regards,
        <br>
        <?php echo e($appname); ?>

    </b>
</h3>
<?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/mail/forget.blade.php ENDPATH**/ ?>