

<?php $__env->startSection('title'); ?>
    Blogs Management <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .blog_img {
            width: 100% !important;
            height: 150px !important;
        }

        .card-body {
            padding: 0px;
        }

        .card {
            padding: 20px;
            border-radius: 5px;
            color: #fff;
        }
    </style>

    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">


                <div class="col-12 allAlerts">
                    <?php if(session()->has('alertMsg')): ?>
                        <div class="alert text-center <?php echo e(session()->get('type')); ?> alert-dismissible fade show"
                            role="alert">
                            <?php echo e(session()->get('alertMsg')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>





                <div class="showAddNewPost mb-5">

                    <div class="add_posts_form">

                        <div class="row">
                            <div class="col">
                                <h2 class="mb-2 mb-md-4 text-center title">
                                    Add New Blog
                                </h2>
                            </div>
                        </div>

                        <form action="/admin/add-new-blog" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>


                            <center>
                                <img src="<?php echo e($sitelogo); ?>" id="logo_pic" alt="Company Logo" class="blog_image"
                                    onclick="clickToChangeLogo(this)">
                            </center>
                            <input type="file" class="comp_logo_input d-none" name="blog_image" accept="image/*"
                                oninput="logo_pic.src=window.URL.createObjectURL(this.files[0])">


                            <div class="form-group">
                                <input type="text" class="form-control" name="blog_title" required
                                    placeholder="Blog Title">
                            </div>

                            <div class="form-group">
                                <label for="">Select Category</label>
                                <select class="form-control" name="blog_category" id="exampleFormControlSelect2">
                                    <?php $__empty_1 = true; $__currentLoopData = $all_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($cat_item->category_name); ?>"><?php echo e($cat_item->category_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <textarea class="form-control" id="tinymce_desc" name="blog_description" placeholder="Blog Description" required
                                    rows="3"></textarea>
                            </div>

                            <button class="btn btn-lg btn-block btn-dark">Upload Blog</button>

                        </form>




                    </div>
                </div>








                <div class="showAddNewPost mb-5">

                    <div class="add_posts_form">

                        <div class="row">
                            <div class="col">
                                <h2 class="mb-2 mb-md-4 text-center title">
                                    All Added Blogs
                                </h2>
                            </div>
                        </div>


                        <div class="row">

                            <?php $__empty_1 = true; $__currentLoopData = $allblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <img src="<?php echo e($item->blog_image); ?>" alt="" class="blog_img">
                                            <h5 class="card-title"><?php echo e($item->blog_title); ?></h5>
                                            <div class="card-text text-dark mb-2">
                                                <?php echo e(substr($item->blog_description, 0, 100)); ?>...
                                            </div>
                                            <a href="/admin/update-blogs/<?php echo e($item->sno); ?>"
                                                class="btn btn-dark btn-block">
                                                View/Update
                                            </a>
                                            <a href="/admin/delete-particular-blog/<?php echo e($item->sno); ?>"
                                                class="btn btn-danger btn-block">
                                                Delete
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>

                        </div>



                    </div>
                </div>







            </div>
        </div>
    </div>


    <script>
        $(".manageblogs").addClass("active");



        function clickToChangeLogo(passedThis) {
            $(".comp_logo_input").click();
        }


        tinymce.init({
            selector: '#tinymce_desc',
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/admin/adminpages/blogpage.blade.php ENDPATH**/ ?>