

<?php $__env->startSection('title'); ?>
    Educational Resources <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- // main webpage content is here  -->
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <h2 class="centered_text">Learn About <?php echo e($appname); ?> </h2>

                        <div class="portal_line">
                            <h3 class="headline_text">
                                How To Videos - <?php echo e($appname); ?>

                            </h3>

                            <div class="item_grid_5">


                                <?php $__empty_1 = true; $__currentLoopData = $edu_resorces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resources): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="item_grid video_grid">
                                        <div class="video_holder">
                                            <?php echo $resources->resource_code; ?>

                                        </div>
                                        <p class="item_title">Welcome to the <?php echo e($appname); ?> Partner Portal (pt. 1)
                                        </p>
                                        <p class="item_desc">Learn about the modules and functions of the
                                            <?php echo e($appname); ?> Partner Portal.</p>
                                        <center>
                                            <button class="continue_btn" onclick="watchIt(this)"
                                                data-id="1">Watch</button>
                                        </center>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>

                            </div>
                        </div>

                    </div>
                </div>

                <div id="styleSelector">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".resources").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('influencers.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/influencers/pages/educational_resources.blade.php ENDPATH**/ ?>