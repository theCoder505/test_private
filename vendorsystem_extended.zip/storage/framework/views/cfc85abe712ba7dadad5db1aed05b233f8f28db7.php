

<?php $__env->startSection('title'); ?>
    New Brands - <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <?php $__empty_1 = true; $__currentLoopData = $brand_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <section class="first_section">
            <h1 class="next_gen_capital_text sec_2_title" contenteditable="true"> <?php echo $brand->sec_2_title; ?></h1>

            <p class="getup_text sec_2_short_desac" contenteditable="true"> <?php echo $brand->sec_2_short_desac; ?></p>


            <div class="container my-5">

                <div class="row affordable">


                    <div class="col-md-4">
                        <div class="image_holder">
                            <img src="<?php echo $brand->supply_img; ?>" alt="photo" class="afford_img supply_img">
                        </div>
                        <p class="affordable_heading supply_title" contenteditable="true"><?php echo $brand->supply_title; ?></p>
                        <p class="affordable_para supply_text" contenteditable="true"><?php echo $brand->supply_text; ?></p>
                    </div>

                    <div class="col-md-4">
                        <div class="image_holder">
                            <img src="<?php echo $brand->fulfil_img; ?>" alt="photo" class="afford_img fulfil_img">
                        </div>
                        <p class="affordable_heading fulfil_title" contenteditable="true"><?php echo $brand->fulfil_title; ?></p>
                        <p class="affordable_para fulfil_text" contenteditable="true"><?php echo $brand->fulfil_text; ?></p>
                    </div>

                    <div class="col-md-4">
                        <div class="image_holder">
                            <img src="<?php echo $brand->ecom_img; ?>" alt="photo" class="afford_img ecom_img">
                        </div>
                        <p class="affordable_heading ecom_title" contenteditable="true"><?php echo $brand->ecom_title; ?></p>
                        <p class="affordable_para ecom_text" contenteditable="true"><?php echo $brand->ecom_text; ?></p>
                    </div>


                </div>

            </div>


            <div class="container">
                <div class="grid_petra_4_lines d-none">

                    <div class="petra_line">
                        <div class="text-center">
                            <img src="<?php echo $brand->sec_2_1_img; ?>" alt="photo" class="petra_img sec_2_1_img">
                        </div>
                        <p class="petra_heading sec_2_1_title" contenteditable="true"><?php echo $brand->sec_2_1_title; ?></p>
                        <p class="petra_details sec_2_1_text" contenteditable="true">
                            <?php echo $brand->sec_2_1_text; ?>

                        </p>
                    </div>

                    <div class="petra_line">
                        <div class="text-center">
                            <img src="<?php echo $brand->sec_2_2_img; ?>" alt="photo" class="petra_img sec_2_2_img">
                        </div>
                        <p class="petra_heading sec_2_2_title" contenteditable="true"><?php echo $brand->sec_2_2_title; ?></p>
                        <p class="petra_details sec_2_2_text" contenteditable="true">
                            <?php echo $brand->sec_2_2_text; ?>

                        </p>
                    </div>

                    <div class="petra_line">
                        <div class="text-center">
                            <img src="<?php echo $brand->sec_2_3_img; ?>" alt="photo" class="petra_img sec_2_3_img">
                        </div>
                        <p class="petra_heading sec_2_3_title" contenteditable="true"><?php echo $brand->sec_2_3_title; ?></p>
                        <p class="petra_details sec_2_3_text" contenteditable="true">
                            <?php echo $brand->sec_2_3_text; ?>

                        </p>
                    </div>

                    <div class="petra_line">
                        <div class="text-center">
                            <img src="<?php echo $brand->sec_2_4_img; ?>" alt="photo" class="petra_img sec_2_4_img">
                        </div>
                        <p class="petra_heading sec_2_4_title" contenteditable="true"><?php echo $brand->sec_2_4_title; ?></p>
                        <p class="petra_details sec_2_4_text" contenteditable="true">
                            <?php echo $brand->sec_2_4_text; ?>

                        </p>
                    </div>

                    <div class="petra_line">
                        <div class="text-center">
                            <img src="<?php echo $brand->sec_2_5_img; ?>" alt="photo" class="petra_img sec_2_5_img">
                        </div>
                        <p class="petra_heading sec_2_5_title" contenteditable="true"><?php echo $brand->sec_2_5_title; ?></p>
                        <p class="petra_details sec_2_5_text" contenteditable="true">
                            <?php echo $brand->sec_2_5_text; ?>

                        </p>
                    </div>

                    <div class="petra_line">
                        <div class="text-center">
                            <img src="<?php echo $brand->sec_2_6_img; ?>" alt="photo" class="petra_img sec_2_6_img">
                        </div>
                        <p class="petra_heading sec_2_6_title" contenteditable="true"><?php echo $brand->sec_2_6_title; ?></p>
                        <p class="petra_details sec_2_6_text" contenteditable="true">
                            <?php echo $brand->sec_2_6_text; ?>

                        </p>
                    </div>

                    <div class="petra_line">
                        <div class="text-center">
                            <img src="<?php echo $brand->sec_2_7_img; ?>" alt="photo" class="petra_img sec_2_7_img">
                        </div>
                        <p class="petra_heading sec_2_7_title" contenteditable="true"><?php echo $brand->sec_2_7_title; ?></p>
                        <p class="petra_details sec_2_7_text" contenteditable="true">
                            <?php echo $brand->sec_2_7_text; ?>

                        </p>
                    </div>

                    <div class="petra_line">
                        <div class="text-center">
                            <img src="<?php echo $brand->sec_2_8_img; ?>" alt="photo" class="petra_img sec_2_8_img">
                        </div>
                        <p class="petra_heading sec_2_8_title" contenteditable="true"><?php echo $brand->sec_2_8_title; ?></p>
                        <p class="petra_details sec_2_8_text" contenteditable="true">
                            <?php echo $brand->sec_2_8_text; ?>

                        </p>
                    </div>

                </div>
            </div>


            <div class="text-center">
                <button class="see_more_less">See More</button>
            </div>


        </section>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>


    <?php echo $__env->make('surface.pages.brands_common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        $(".new_brands").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/surface/pages/new-brands.blade.php ENDPATH**/ ?>