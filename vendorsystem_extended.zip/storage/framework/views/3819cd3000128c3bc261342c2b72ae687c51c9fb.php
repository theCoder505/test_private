

<?php $__env->startSection('title'); ?>
    Welcome To <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- // main webpage content is here  -->
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <h2 class="centered_text">Welcome back to <?php echo e($appname); ?> </h2>

                        <div class="portal_line">
                            <h3 class="headline_text">
                                Get started with <?php echo e($appname); ?>

                            </h3>

                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resources): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="item_grid_4">


                                    <div class="item_grid">
                                        <div class="item_img_holder">
                                            <img src="<?php echo e(asset('vendor/assets/images/training.png')); ?>" alt=""
                                                class="item_img">
                                        </div>
                                        <p class="item_title">Training Module</p>
                                        <p class="item_desc">Learn how to use the Partner Portal to find
                                            customers and...</p>
                                        <center>
                                            <a href="<?php echo e($resources->traning_module); ?>" class="continue_btn">Continue
                                                Reading</a>
                                        </center>
                                    </div>

                                    <div class="item_grid">
                                        <div class="item_img_holder">
                                            <img src="<?php echo e(asset('vendor/assets/images/bill.png')); ?>" alt=""
                                                class="item_img">
                                        </div>
                                        <p class="item_title">Invoicing & Fulfillment</p>
                                        <p class="item_desc">Learn how to properly invoice and fulfill
                                            Creator
                                            orders.</p>
                                        <center>
                                            <a href="<?php echo e($resources->invoicing_fullfilment); ?>" class="continue_btn">Continue
                                                Reading</a>
                                        </center>
                                    </div>

                                    <div class="item_grid">
                                        <div class="item_img_holder">
                                            <img src="<?php echo e(asset('vendor/assets/images/guide.png')); ?>" alt=""
                                                class="item_img">
                                        </div>
                                        <p class="item_title">Receiving Guidelines</p>
                                        <p class="item_desc">Review how to ship products to <?php echo e($appname); ?>'s
                                            Fulfillment Center...</p>
                                        <center>
                                            <a href="<?php echo e($resources->receiving_guidelines); ?>" class="continue_btn">Continue
                                                Reading</a>
                                        </center>
                                    </div>

                                    <div class="item_grid">
                                        <div class="item_img_holder">
                                            <img src="<?php echo e(asset('vendor/assets/images/profile_avatar_man.png')); ?>"
                                                alt="" class="item_img">
                                        </div>
                                        <p class="item_title">Set Up Business Profile</p>
                                        <p class="item_desc">Describe your business and its private label
                                            and...
                                        </p>
                                        <center>
                                            <a href="<?php echo e($resources->setup_business_profile); ?>"
                                                class="continue_btn">Continue Reading</a>
                                        </center>
                                    </div>

                                    <div class="item_grid">
                                        <div class="item_img_holder">
                                            <img src="<?php echo e(asset('vendor/assets/images/request-payment.png')); ?>"
                                                alt="" class="item_img">
                                        </div>
                                        <p class="item_title">Set Up Direct Deposit</p>
                                        <p class="item_desc">Allow Creators to send you money for each
                                            order...
                                        </p>
                                        <center>
                                            <a href="<?php echo e($resources->orders_shipments); ?>" class="continue_btn">Continue
                                                Reading</a>
                                        </center>
                                    </div>



                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </div>



                        <div class="portal_line">
                            <h3 class="headline_text">
                                Keeping Up With Customers
                            </h3>

                            <div class="item_grid_4">


                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/messages.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Your Customer Messages</p>
                                    <p class="item_desc">Reply Customers Soon...</p>
                                    <center>
                                        <a href="https://web.whatsapp.com/" class="continue_btn">Continue</a>
                                    </center>
                                </div>

                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/orders.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Orders & Shipments</p>
                                    <p class="item_desc">Track Your Orders</p>
                                    <center>
                                        <a href="/menufacturer/Orders-&-Shipments" class="continue_btn">Continue</a>
                                    </center>
                                </div>

                            </div>
                        </div>


                        <div class="portal_line">
                            <h3 class="headline_text">
                                Find New Customers
                            </h3>

                            <div class="item_grid_4">


                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/links.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">share Profile To Influencer</p>
                                    <br>
                                    <center>
                                        <button class="continue_btn copy_link"
                                            onclick="copy_link(this)" data-link="<?php echo e(url('/')); ?>/see-vendor-profile/menufacturer/<?php echo e($loggerUniqueId); ?>">
                                            Copy Link
                                        </button>
                                    </center>
                                </div>

                                <div class="item_grid">
                                    <div class="item_img_holder">
                                        <img src="<?php echo e(asset('vendor/assets/images/links.png')); ?>" alt=""
                                            class="item_img">
                                    </div>
                                    <p class="item_title">Share Profile To Enterprenuer</p>
                                    <br>
                                    <center>
                                        <button class="continue_btn copy_link"
                                            onclick="copy_link(this)" data-link="<?php echo e(url('/')); ?>/entrepreneur/see-vendor-profile/menufacturer/<?php echo e($loggerUniqueId); ?>">
                                            Copy Link
                                        </button>
                                    </center>
                                </div>

                            </div>
                        </div>


                        <div class="portal_line">
                            <h3 class="headline_text">
                                How To Videos - <?php echo e($appname); ?>

                            </h3>

                            <div class="item_grid_4">


                                <?php $__empty_1 = true; $__currentLoopData = $edu_rsrc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu_last_rsrcs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="item_grid video_grid">
                                        <div class="video_holder">
                                            <?php echo $edu_last_rsrcs->resource_code; ?>

                                        </div>
                                        <p class="item_title">Welcome to the <?php echo e($appname); ?> Partner Portal (pt. 1)
                                        </p>
                                        <p class="item_desc">Learn about the modules and functions of the
                                            <?php echo e($appname); ?> Partner Portal.</p>
                                        <center>
                                            <button class="continue_btn" onclick="watchIt(this)"
                                                data-id="1">Watch</button>
                                        </center>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>


                                <div class="total_center">
                                    <a href="/2" class="centered_watch_text">View All</a>
                                </div>



                            </div>
                        </div>

                    </div>
                </div>

                <div id="styleSelector">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".home").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('menufacturers.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/menufacturers/pages/dashboard.blade.php ENDPATH**/ ?>