

<?php $__env->startSection('title'); ?>
    Read Particular Blog From - <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="container my-5">

        <?php $__empty_1 = true; $__currentLoopData = $question_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="super_blog_title"><?php echo e($item->title); ?> </div>

            <div class="row w-75 mx-auto my-5">
                <div class="col-md-6">
                    <div class="author">
                        <img src="<?php echo e($siteicon); ?>" alt="" class="author_img">
                        <div class="">
                            <div class="author_name"><?php echo e($appname); ?> </div>
                            <div class="blog_time text-left mb-1"> <?php echo e(date('F d, Y', strtotime($item->deadline))); ?> </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 text-right">
                    <a href="<?php echo e($linkedIn); ?>" target="_blank" class="circularLink">
                        <i class="fa fa-linkedin"></i>
                    </a>
                    <a href="<?php echo e($fb); ?>" target="_blank" class="circularLink mx-2">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a href="<?php echo e($insta); ?>" target="_blank" class="circularLink">
                        <i class="fa fa-instagram"></i>
                    </a>
                </div>

            </div>


            <img src="<?php echo e($item->question_image); ?>" alt="" class="blog_thumbnail_img">


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>




        <div id="content_holder">

            <div id="left_section">
                <div class="content_blue_div">
                    <img src="<?php echo e($sitelogo); ?>" alt="" class="weblogo">
                    <h5 class="text-center my-3">
                        Q&A Content for the Open Web
                    </h5>
                    <a href="/sign-in" class="btn get_started_btn">Get Started</a>
                </div>
                <div class="table_of_contents">
                    <h5 class="">Table of Contents</h5>
                    <a class="table_query"><?php echo e($main_question); ?></a>

                    <?php $__empty_1 = true; $__currentLoopData = $related_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="#answer<?php echo e($key2 + 1); ?>" class="table_query"><?php echo e($blog->answer_headline); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </div>
            </div>




            <div id="all_related_answers">

                <h2 class="arial"><?php echo e($main_question); ?> </h2>
                <p class="arial user_answer mt-4"><?php echo e($main_question_details); ?> </p>

                <ul class="mb-5">
                    <?php $__empty_1 = true; $__currentLoopData = $related_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li><?php echo e($blog->answer_headline); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </ul>

                <?php $__empty_1 = true; $__currentLoopData = $related_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="answer_line" id="answer<?php echo e($key2 + 1); ?>">
                        <div class="answer_title"><?php echo e($blog->answer_headline); ?></div>
                        <div class="user_answer"><?php echo $blog->user_answer; ?></div>
                        <div class="user_info">
                            <div class="left_user_image">
                                <img src="<?php echo e($blog->user_comp_image); ?>" alt="image" class="w-100">
                            </div>
                            <div class="right_all_texts">
                                <a href="<?php echo e($blog->user_linkedin_url); ?>"
                                    class="linked_in_profile"><?php echo e($blog->user_acc_name); ?></a> <br>
                                <span class="capitalize"> <?php echo e($blog->user_full_name); ?> </span> as <span
                                    class="capitalize"><?php echo e($blog->replier_type); ?></span> at
                                <?php echo e($appname); ?>,
                                <a href="<?php echo e($blog->user_website); ?>"
                                    class="linked_in_profile"><?php echo e($blog->user_business_name); ?></a>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>

                <div class="answer_line mt-4">

                    <div class="answer_title">Submit Your Answer</div>
                    <div class="user_answer">
                        Would you like to submit an alternate answer to the question, “What’s the best client thank you gift
                        you’ve ever given?”
                    </div>
                    <a href="/sign-in" class="linked_in_profile">Submit your answer here.</a>
                </div>

                <div class="answer_line">
                    <div class="answer_title">
                        Related Questions
                    </div>
                    <?php $__empty_1 = true; $__currentLoopData = $related_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($key < 4): ?>
                            <a href="/read-experts-articles/<?php echo e($questions->question_id); ?>/<?php echo e($questions->title); ?>"
                                class="linked_in_profile"><?php echo e($questions->title); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </div>
            </div>

        </div>






    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        $(".blogs_with_experts").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/surface/pages/specific_experts_blog.blade.php ENDPATH**/ ?>