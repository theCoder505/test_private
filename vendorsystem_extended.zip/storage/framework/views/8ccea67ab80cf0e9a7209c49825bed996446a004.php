

<?php $__env->startSection('title'); ?>
    Read Our Blogs And Know What Experts Say | <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <style>
        .blog_small_desc {
            text-transform: capitalize;
        }
    </style>




    <div class="container">



        <div class="row">

            <div class="col-md-12">
                <h2 class="text-center font-weight-bold mt-5 mb-3">What Our Experts Say?</h2>
                <div class="all_post_tablines_2">
                    <a class="post_tabline_2 active_line" href="/read-blogs" onclick="showSpecAllPosts(this)"> All Industries
                    </a>

                    <?php $__empty_1 = true; $__currentLoopData = $industry_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a class="post_tabline_2 text-dark" href="/read-blog-with-experts/category/<?php echo e($item->option_name); ?>"
                            onclick="showSpecIndustryPosts(this)">
                            <?php echo e($item->option_name); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-8">

                <div class="experts_sayings">
                    <div class="blog-container">


                        <?php $__empty_1 = true; $__currentLoopData = $admin_queries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="blog_item_2 common_exprt_blog" data-id='<?php echo e($blog->industries_data); ?>'>
                                <img src="<?php echo e($blog->question_image); ?>" alt="Image" class="blog_img">
                                <div class="blog_detail_part">
                                    <a class="blog_title text-dark"
                                        href="/read-experts-articles/<?php echo e($blog->question_id); ?>/<?php echo e($blog->title); ?>">
                                        <?php echo e($blog->title); ?>

                                    </a>
                                    <div class="blog_time">
                                        <?php echo e(str_replace(['[', ']', '"', ','], ['', '', '', ', '], $blog->industries_data)); ?>

                                    </div>
                                    <div class="blog_time">
                                        <?php echo e(date('F d, Y', strtotime($blog->added_time))); ?>

                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>


                    </div>
                </div>


            </div>

            <div class="col-md-4">


                <form action="/search-results" method="get">
                    <div id="search_box">
                        <input type="text" class="search_input" placeholder="Enter search terms" name="search" required>
                        <button class="btn btn_search">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </form>

                <div class="bg-info text-center font-weight-bold btn-circle btn btn-block text-light mt-4">
                    Questions & Answers
                </div>


                <?php $__empty_1 = true; $__currentLoopData = $admin_queries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question_key => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($question_key < 15): ?>
                        <a href="/read-experts-articles/<?php echo e($blog->question_id); ?>/<?php echo e($blog->title); ?>"
                            class="side_blog_title">
                            <div>
                                <?php echo e($blog->title); ?>

                            </div>
                            <div class="blog_side_text">
                                <?php echo e(date('F d, Y', strtotime($blog->added_time))); ?>

                            </div>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>

            </div>


            <div class="col-md-12">

                <div class="web_blogs">
                    <h2 class="text-center font-weight-bold my-3"><?php echo e($appname); ?> Blogs</h2>
                    <div class="all_post_tablines">
                        <a class="post_tabline active_line" href="/read-blogs#<?php echo e($appname); ?>_blogs"> All Posts </a>
                        <?php $__empty_1 = true; $__currentLoopData = $blog_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a class="post_tabline text-dark"
                                href="/read-specific-blogs/category/<?php echo e($category->category_name); ?>">
                                <?php echo e($category->category_name); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </div>

                </div>
            </div>



            <div class="col-md-12" id="<?php echo e($appname); ?>_blogs">
                <div class="blog_container_added">


                    <?php $__empty_1 = true; $__currentLoopData = $blog_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="blog_item" data-class="<?php echo e($blog->blog_category); ?>">
                            <img src="<?php echo e($blog->blog_image); ?>" alt="" class="blog_img">
                            <div class="blog_detail_part">
                                <a href="/see-blog/<?php echo e($blog->sno); ?>/<?php echo e($blog->blog_category); ?>/<?php echo e($blog->blog_title); ?>"
                                    class="blog_title">
                                    <?php echo e($blog->blog_title); ?>

                                </a>
                                <div class="blog_time">
                                    <?php echo e(date('F d, Y', strtotime($blog->time))); ?>

                                </div>
                                <p class="blog_small_desc">
                                    <?php echo e(substr($blog->blog_description, 0, 100)); ?>...
                                </p>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>


                </div>
            </div>


        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        $(".blogs").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/surface/pages/blogs.blade.php ENDPATH**/ ?>