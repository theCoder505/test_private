

<?php $__env->startSection('title'); ?>
    Setup Your Profile At <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .portal_line {
            padding: 50px;
            border-radius: 15px;
            border: 2px solid #000 !important;
            background: #fff;
        }

        .user_comp_logo {
            margin: 15px auto;
            text-align: center;
            border: 0px;
            border-radius: 0%;
            width: 200px;
            height: auto;
        }
    </style>


    <!-- // main webpage content is here  -->
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">

                        <div class="col-12 allAlerts">
                            <?php if(session()->has('alertMsg')): ?>
                                <div class="alert text-center <?php echo e(session()->get('type')); ?> alert-dismissible fade show"
                                    role="alert">
                                    <?php echo e(session()->get('alertMsg')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>

                        <h2 class="centered_text"> Setup Your Profile At <?php echo e($appname); ?> </h2>

                        <div class="portal_line">
                            <h3 class="headline_text">
                                Complete Your <?php echo e($appname); ?> Profile
                            </h3>


                            <?php $__empty_1 = true; $__currentLoopData = $vendor_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $company_logo = $item->company_logo;
                                    $business_name = $item->business_name;
                                    $comp_bio = $item->comp_bio;
                                    $pdf_file = $item->pdf_file;
                                    $phone_number = $item->phone_number;
                                    $partner_account = $item->partner_account;
                                    $attributes = $item->attributes;
                                    $industry_options = $item->industry_options;
                                    $country = $item->country;
                                    $state = $item->state;
                                    $create_n_ship_time = $item->create_n_ship_time;
                                    $typical_run_time = $item->typical_run_time;
                                    $avg_yearly_sales = $item->avg_yearly_sales;
                                    $notable_projects = $item->notable_projects;
                                    $linkedin_url = $item->linkedin_url;
                                    $website_url = $item->website_url;
                                    $project_gallery = $item->project_gallery;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php
                                    $company_logo = asset('vendor/assets/images/user.jpg');
                                    $business_name = '';
                                    $comp_bio = '';
                                    $pdf_file = '';
                                    $phone_number = '';
                                    $partner_account = '';
                                    $attributes = '';
                                    $industry_options = '';
                                    $country = '';
                                    $state = '';
                                    $create_n_ship_time = '';
                                    $typical_run_time = '';
                                    $avg_yearly_sales = '';
                                    $notable_projects = '';
                                    $linkedin_url = '';
                                    $website_url = '';
                                    $project_gallery = '';
                                ?>
                            <?php endif; ?>



                            <div id="complete_profile">
                                <form action="/influencer/complete-user-profile" method="post"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <center>
                                        <img src="<?php echo e($company_logo); ?>" id="logo_pic" alt="Company Logo"
                                            class="user_comp_logo" onclick="clickToChangeLogo(this)">
                                    </center>
                                    <input type="file" class="comp_logo_input d-none" name="user_comp_logo"
                                        accept="image/*" oninput="logo_pic.src=window.URL.createObjectURL(this.files[0])">


                                    <div class="form-group">
                                        <label>Business Name For Your Profile</label>
                                        <input type="text" class="form-control" required value="<?php echo e($business_name); ?>"
                                            name="business_name">
                                    </div>

                                    <div class="form-group">
                                        <label>Company Bio</label>
                                        <textarea class="form-control" id="comp_bio" name="comp_bio" rows="3" required><?php echo e($comp_bio); ?></textarea>
                                    </div>

                                    <div class="form-group">
                                        <label>
                                            Company Catalog PDF
                                            <?php if($pdf_file != ''): ?>
                                                ( <a class="text-primary" href="<?php echo e($pdf_file); ?>" download>See PDF</a> )
                                            <?php endif; ?>
                                        </label>

                                        <input type="file" class="form-control" name="comp_pdf" accept=".doc,.docx,.pdf">
                                    </div>

                                    <div class="form-group">
                                        <label> Contact Phone Number </label>
                                        <input type="number" class="form-control" required value="<?php echo e($phone_number); ?>"
                                            name="phone_number" maxlength="15">
                                    </div>

                                    <div class="text-dark font-weight-bold my-3"> Select industries, you are related with:
                                    </div>
                                    <div class="row px-3">

                                        <?php $__empty_1 = true; $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key22 => $industries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class=" col-md-4">
                                                <input class="" type="checkbox" id="industry<?php echo e($key22); ?>"
                                                    value="<?php echo e($industries->option_name); ?>" name="industries_data[]"
                                                    <?php if(strpos($industry_options, $industries->option_name) !== false): ?> checked <?php endif; ?>>
                                                <label class="form-check-label"
                                                    for="industry<?php echo e($key22); ?>"><?php echo e($industries->option_name); ?></label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>

                                    </div>

                                    <div class="form-group">
                                        <label> LinkedIn URL </label>
                                        <input type="text" class="form-control" required
                                            value="<?php echo e($linkedin_url); ?>" name="linkedin_url">
                                    </div>

                                    <div class="form-group">
                                        <label> Website URL </label>
                                        <input type="text" class="form-control" required
                                            value="<?php echo e($website_url); ?>" name="website_url">
                                    </div>

                                    <div class="row my-2">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label> Country/Region</label>
                                                <input type="text" class="form-control" required
                                                    value="<?php echo e($country); ?>" name="country_name">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label> State </label>
                                                <input type="text" class="form-control" required
                                                    value="<?php echo e($state); ?>" name="state">
                                            </div>
                                        </div>
                                    </div>


                                    <center>
                                        <button class="btn btn-dark px-5">Complete Profile</button>
                                    </center>


                                </form>



                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(".profile").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('entrepreneurs.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/entrepreneurs/pages/profile_setup.blade.php ENDPATH**/ ?>