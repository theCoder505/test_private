

<?php $__env->startSection('title'); ?>
    Read Our Blogs And Know What Experts Say | <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <style>
        .blog_small_desc {
            text-transform: capitalize;
        }
    </style>




    <div class="container">



        <div class="row">
            <div class="col-md-12">

                <div class="experts_sayings">
                    <h1 class="text-center font-weight-bold my-3">
                        Category: <?php echo e($category_name); ?>

                    </h1>
                    <div class="all_post_tablines_2">
                        <a class="post_tabline_2 text-dark" href="/read-blogs" onclick="showSpecAllPosts(this)"> All Industries </a>

                        <?php $__empty_1 = true; $__currentLoopData = $industry_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a class="post_tabline_2 text-dark <?php if($category_name == $item->option_name): ?> active_line <?php endif; ?>"
                                href="/read-blog-with-experts/category/<?php echo e($item->option_name); ?>"
                                onclick="showSpecIndustryPosts(this)">
                                <?php echo e($item->option_name); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </div>


                    <div class="blog_container_added">
                        <?php $__empty_1 = true; $__currentLoopData = $admin_queries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="blog_item common_exprt_blog" data-id='<?php echo e($blog->industries_data); ?>'>
                                <img src="<?php echo e($blog->question_image); ?>" alt="Image" class="blog_img">
                                <div class="blog_detail_part">
                                    <a class="blog_title"
                                        href="/read-experts-articles/<?php echo e($blog->question_id); ?>/<?php echo e($blog->title); ?>">
                                        <?php echo e($blog->title); ?>

                                    </a>
                                    <div class="blog_time">
                                        <?php echo e(str_replace(['[', ']', '"', ','], ['', '', '', ', '], $blog->industries_data)); ?>

                                    </div>
                                    <div class="blog_time">
                                        <?php echo e(date('F d, Y', strtotime($blog->added_time))); ?>

                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h1></h1>
                            <h1 class="text-danger text-center">No Related Blogs In This Category</h1>
                        <?php endif; ?>
                    </div>
                </div>



            </div>


        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/surface/pages/blog_with_spec_cat.blade.php ENDPATH**/ ?>