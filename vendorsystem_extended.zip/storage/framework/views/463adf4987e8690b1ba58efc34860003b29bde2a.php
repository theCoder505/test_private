

<?php $__env->startSection('title'); ?>
    Add New Post & See All Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">


                <div class="col-12 allAlerts">
                    <?php if(session()->has('alertMsg')): ?>
                        <div class="alert text-center <?php echo e(session()->get('type')); ?> alert-dismissible fade show"
                            role="alert">
                            <?php echo e(session()->get('alertMsg')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>





                <div class="showAddNewPost mb-5">

                    <div class="add_posts_form">

                        <div class="row">
                            <div class="col">
                                <h2 class="mb-2 mb-md-4 text-center title">
                                    Check & Change Users Activity
                                </h2>
                            </div>
                        </div>


                        <div class="overflow_auto">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Full Name</th>
                                        <th scope="col">Account Name</th>
                                        <th scope="col">Account Email</th>
                                        <th scope="col">Account Type</th>
                                        <th scope="col">OTP Verified?</th>
                                        <th scope="col">Activity Status</th>
                                        <th scope="col">Change Activity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $all_users_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <form action="/admin/update-users-activity" method="post">
                                                <?php echo csrf_field(); ?>

                                                <td>
                                                    <?php echo e($key + 1); ?>

                                                </td>

                                                <td>
                                                    <input type="hidden" value="<?php echo e($item->user_unique_id); ?>"
                                                        name="serial">
                                                    <?php echo e($item->full_name); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($item->acc_name); ?>

                                                </td>
                                                <td>
                                                    <div class="uppercase"> <?php echo e($item->type); ?> </div>
                                                </td>
                                                <td>
                                                    <a href="mailto:<?php echo e($item->user_email); ?>"><?php echo e($item->user_email); ?></a>
                                                </td>
                                                <td>
                                                    <?php if($item->status > 0): ?>
                                                        <div class="btn btn-success btn-sm">Verified</div>
                                                    <?php else: ?>
                                                        <div class="btn btn-danger btn-sm">Not Verified</div>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <?php if($item->activity_status_by_admin > 0): ?>
                                                        <div class="btn btn-primary btn-sm">Active</div>
                                                    <?php else: ?>
                                                        <div class="btn btn-danger btn-sm">Deactivated</div>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <?php if($item->activity_status_by_admin > 0): ?>
                                                        <button class="btn btn-danger btn-sm">Deactivate</button>
                                                    <?php else: ?>
                                                        <button class="btn btn-primary btn-sm">Activate</button>
                                                    <?php endif; ?>
                                                </td>
                                            </form>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>


                    </div>
                </div>


            </div>
        </div>
    </div>


    <script>
        $(".manageusersactivity").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/admin/adminpages/users_activity.blade.php ENDPATH**/ ?>