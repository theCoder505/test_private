

<?php $__env->startSection('title'); ?>
    Search Results For <?php echo e($search_item); ?> at <?php echo e($appname); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <style>
        .blog_small_desc {
            text-transform: capitalize;
        }
    </style>




    <div class="container">



        <div class="row">

            <div class="col-md-12">
                <h2 class="text-center font-weight-bold mt-5 mb-3">
                    Search Results For: <?php echo e($search_item); ?>

                </h2>
            </div>

            <div class="col-md-12">

                <div class="experts_sayings">
                    <div class="blog_container_added">


                        <?php $__empty_1 = true; $__currentLoopData = $admin_queries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="blog_item common_exprt_blog" data-id='<?php echo e($blog->industries_data); ?>'>
                                <img src="<?php echo e($blog->question_image); ?>" alt="Image" class="blog_img">
                                <div class="blog_detail_part">
                                    <a class="blog_title text-dark"
                                        href="/read-experts-articles/<?php echo e($blog->question_id); ?>/<?php echo e($blog->title); ?>">
                                        <?php echo e($blog->title); ?>

                                    </a>
                                    <div class="blog_time">
                                        <?php echo e(str_replace(['[', ']', '"', ','], ['', '', '', ', '], $blog->industries_data)); ?>

                                    </div>
                                    <div class="blog_time">
                                        <?php echo e(date('F d, Y', strtotime($blog->added_time))); ?>

                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h1></h1>
                            <h4 class="text-center text-danger">No Related Question Found!</h4>
                        <?php endif; ?>


                    </div>
                </div>


            </div>


            <div class="col-md-12">

                <div class="web_blogs">
                    <h2 class="text-center font-weight-bold my-3">
                        <?php echo e($appname); ?> Blogs | Search Results For: <?php echo e(request()->query('search')); ?>

                    </h2>
                </div>
            </div>



            <div class="col-md-12" id="<?php echo e($appname); ?>_blogs">
                <div class="blog_container_added">


                    <?php $__empty_1 = true; $__currentLoopData = $blog_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="blog_item" data-class="<?php echo e($blog->blog_category); ?>">
                            <img src="<?php echo e($blog->blog_image); ?>" alt="" class="blog_img">
                            <div class="blog_detail_part">
                                <a href="/see-blog/<?php echo e($blog->sno); ?>/<?php echo e($blog->blog_category); ?>/<?php echo e($blog->blog_title); ?>"
                                    class="blog_title">
                                    <?php echo e($blog->blog_title); ?>

                                </a>
                                <div class="blog_time">
                                    <?php echo e(date('F d, Y', strtotime($blog->time))); ?>

                                </div>
                                <p class="blog_small_desc">
                                    <?php echo e(substr($blog->blog_description, 0, 100)); ?>...
                                </p>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h1></h1>
                        <h4 class="text-center text-danger">No Related Blogs Found!</h4>
                    <?php endif; ?>


                </div>
            </div>


        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('surface.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/surface/pages/blog_search_results.blade.php ENDPATH**/ ?>