

<?php $__env->startSection('title'); ?>
    Add New Post & See All Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">


                <div class="col-12 allAlerts">
                    <?php if(session()->has('alertMsg')): ?>
                        <div class="alert text-center <?php echo e(session()->get('type')); ?> alert-dismissible fade show"
                            role="alert">
                            <?php echo e(session()->get('alertMsg')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>





                <div class="showAddNewPost mb-5">

                    <div class="add_posts_form">

                        <div class="row">
                            <div class="col">
                                <h2 class="mb-2 mb-md-4 text-center title">
                                    Update Particular Post
                                </h2>
                            </div>
                        </div>



                        <form action="/admin/manage-page-data" method="post">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" class="_token" value="<?php echo csrf_token(); ?>">
                            <div class="form-group">
                                <label for="">Select Page Type:</label>
                                <select name="select_page" class="form-control" onchange="showData(this)">
                                    <option value="publications">Publications Portal</option>
                                    <option value="realestate">Real Estate Law</option>
                                    <option value="projects">Real Estate Projects</option>
                                    <option value="aboutus">Our company</option>
                                </select>

                                <div class="form-group mt-4">
                                    <label for="">Update Content:</label>
                                    <textarea class="form-control" required name="content" id="update_content" rows="3"><?php echo e($publications_data); ?></textarea>
                                </div>

                                <center>
                                    <button class="btn btn-primary px-5">UPDATE</button>
                                </center>
                            </div>

                        </form>

                    </div>
                </div>


            </div>
        </div>
    </div>


    <script>
        $(".managepages").addClass("active");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\vendorSystem\resources\views/admin/adminpages/manage_pages.blade.php ENDPATH**/ ?>