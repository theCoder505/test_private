<center>
    <h1>Dear User, <br> Welsome to "<i> {{ $appname }} </i>" </h1>
</center>
<hr>
<hr>


<p>You have a 6 Digit OTP to continue on {{$appname}}. It is below. <br>

<p>The OTP is : <b>{{ $theOtp }}</b></p>
<br>
<br>
<i> If you did not tried to open the account, no further action is required. </i>

<br>
</p>

<hr>
<hr>

<h3>
    <b>
        Best Regards,
        <br>
        {{ $appname }}
    </b>
</h3>
