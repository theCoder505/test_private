<center>
    <h1>Email for Admin for changing mail from "<i> {{ $appname}} </i>" </h1>
</center>
<hr>
<hr>


<p>
    Dear Admin, as you requested a email change option in your website - {{ $appname}}. <br>
    We are providing you a 6 digit OTP. Use this OTP and continue... <br>

<p>The OTP is : <b>{{ $theOtp }}</b></p>
<br>
<br>
<i> If you did not tried to open the account, no further action is required. </i>

<br>
</p>

<hr>
<hr>

<h3>
    <b>
        Best Regards,
        <br>
        {{ $appname}}
    </b>
</h3>
